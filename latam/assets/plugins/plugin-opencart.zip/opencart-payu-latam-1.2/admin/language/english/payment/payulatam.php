<?php
$_['heading_title']         = 'PayuLatam';
$_['text_payment']          = 'Payment';
$_['text_success']          = 'Success: You have modified PayuLatam account details!';

$_['production_url']        = 'Production Url';
$_['test_url']              = 'Test Url';
$_['test_mode']             = 'Test Mode?';

$_['merchant_id']           = 'Merchant Id';
$_['account_id']            = 'Account Id';
$_['api_key']               = 'API Key';

$_['approved_transaction']  = 'Approved Transaction';
$_['pending_transaction']   = 'Pending Transaction';
$_['declined_transaction']  = 'Declined Transaction';

$_['min_amount']            = 'Min Amount';
$_['status']                = 'Status';

$_['err_permission']        = 'Error: You dont have sufficient privileges to modify Payulatam payment';
?>