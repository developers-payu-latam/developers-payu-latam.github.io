<?php
class ModelPaymentPayulatam extends Model {
  public function getMethod($address, $total) {

    $this->language->load('payment/payulatam');
    
    $method_data = array(
        'code'       => 'payulatam',
        'title'      => $this->language->get('text_title'),
        'sort_order' => $this->config->get('payulatam_sort_order')
    );

    return $method_data;
  }
}

?>