<?php

/*
  $Id: PayU Latam 22/04/2014 $

  PayU Latam module payment for Oscommerce 2.3.3.4
  http://www.payulatam.com

  @copyright  Copyright (c) 2014 PayU Latam
*/

class payu_latam {
	var $code, $title, $description, $enabled;

	/*
	 * Constructor de la clase y donde se define las vaariables a utilizar
	 */
	function payu_latam() {
	
		global $order, $currency;
		$this->signature = 'payu|payu_latam|1.0';
		
		$this->code = 'payu_latam';
		$this->title = MODULE_PAYMENT_PAYU_LATAM_TEXT_TITLE;
		$this->public_title = MODULE_PAYMENT_PAYU_LATAM_TEXT_PUBLIC_TITLE;
		$this->description = MODULE_PAYMENT_PAYU_LATAM_TEXT_DESCRIPTION;
		$this->sort_order = MODULE_PAYMENT_PAYU_LATAM_SORT_ORDER;
		if ((MODULE_PAYMENT_PAYU_LATAM_STATUS == 'True') && ($currency == 'ARS' || $currency == 'BRL' || $currency == 'COP' || $currency == 'MXN' || $currency == 'PEN' || $currency == 'USD')){
			$this->enabled = true;
		} else {
			$this->enabled = false;
		}
		
		$this->form_action_url = MODULE_PAYMENT_PAYU_LATAM_GATEWAY_URL;
	}
	
	function update_status() {
	
      global $order;

      if ( ($this->enabled == true) && ((int)MODULE_PAYMENT_PAYU_LATAM_ZONE > 0) ) {
        $check_flag = false;
        $check_query = tep_db_query("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_PAYU_LATAM_ZONE . "' and ( zone_country_id = 0 or zone_country_id = '" . $order->billing['country']['id'] . "' ) order by zone_id");
        while ($check = tep_db_fetch_array($check_query)) {
          if ($check['zone_id'] < 1) {
            $check_flag = true;
            break;
          } elseif ($check['zone_id'] == $order->billing['zone_id']) {
            $check_flag = true;
            break;
          }
        }

        if ($check_flag == false) {
          $this->enabled = false;
        }
      }
    }
	
	function javascript_validation() {
	
      return false;
    }
	
	function selection() {
	
      return array('id' => $this->code,
                   'module' => $this->public_title);
    }
	
	function pre_confirmation_check() {
	
      return false;
    }
	function confirmation() {
	
      return false;
    }
	
	/*
	 * Verifica que el modulo de pago ha sido instalado
	 */
	function check() {
	
      if (!isset($this->_check)) {
        $check_query = tep_db_query("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_PAYU_LATAM_STATUS'");
        $this->_check = tep_db_num_rows($check_query);
      }
      return $this->_check;
    }
	
	/*
	 * Define los parametros de configuracion del modulo los cuales son mostrados en el admin de Oscommerce
	 */
	function install() {
	
		//************ CREACION DE LOS ESTADOS EN LOS TRES IDIOMAS ************//		
		$status_query = tep_db_query("select max(orders_status_id) as status_id from " . TABLE_ORDERS_STATUS);
        $status = tep_db_fetch_array($status_query);
		$status_id = $status['status_id']+1;
		
		$spanish_query = tep_db_query("select languages_id id from languages where code = 'es' limit 1");		
		if (tep_db_num_rows($spanish_query) > 0) {
			$spanish = tep_db_fetch_array($spanish_query);
			
			$sql_data_array = array('orders_status_id' => $status_id++,
									'language_id' => $spanish['id'],
									'orders_status_name' => 'Aprobada');
			tep_db_perform(TABLE_ORDERS_STATUS, $sql_data_array);
			
			$sql_data_array = array('orders_status_id' => $status_id++,
									'language_id' => $spanish['id'],
									'orders_status_name' => 'Rechazada');
			tep_db_perform(TABLE_ORDERS_STATUS, $sql_data_array);
			
			$sql_data_array = array('orders_status_id' => $status_id++,
									'language_id' => $spanish['id'],
									'orders_status_name' => 'Fallida');
			tep_db_perform(TABLE_ORDERS_STATUS, $sql_data_array);
			
			$sql_data_array = array('orders_status_id' => $status_id++,
									'language_id' => $spanish['id'],
									'orders_status_name' => 'Pendiente');
			tep_db_perform(TABLE_ORDERS_STATUS, $sql_data_array);
		}
		
		$english_query = tep_db_query("select languages_id id from languages where code = 'en' limit 1");		
		if (tep_db_num_rows($english_query) > 0) {
			$english = tep_db_fetch_array($english_query);
			
			$sql_data_array = array('orders_status_id' => $status_id++,
									'language_id' => $english['id'],
									'orders_status_name' => 'Approved');
			tep_db_perform(TABLE_ORDERS_STATUS, $sql_data_array);
			
			$sql_data_array = array('orders_status_id' => $status_id++,
									'language_id' => $english['id'],
									'orders_status_name' => 'Rejected');
			tep_db_perform(TABLE_ORDERS_STATUS, $sql_data_array);
			
			$sql_data_array = array('orders_status_id' => $status_id++,
									'language_id' => $english['id'],
									'orders_status_name' => 'Failed');
			tep_db_perform(TABLE_ORDERS_STATUS, $sql_data_array);
			
			$sql_data_array = array('orders_status_id' => $status_id++,
									'language_id' => $english['id'],
									'orders_status_name' => 'Pending');
			tep_db_perform(TABLE_ORDERS_STATUS, $sql_data_array);
		}
		
		$portuguese_query = tep_db_query("select languages_id id from languages where code = 'pt' limit 1");		
		if (tep_db_num_rows($portuguese_query) > 0) {
			$portuguese = tep_db_fetch_array($portuguese_query);
			
			$sql_data_array = array('orders_status_id' => $status_id++,
									'language_id' => $portuguese['id'],
									'orders_status_name' => 'Aprovado');
			tep_db_perform(TABLE_ORDERS_STATUS, $sql_data_array);
			
			$sql_data_array = array('orders_status_id' => $status_id++,
									'language_id' => $portuguese['id'],
									'orders_status_name' => 'Recusada');
			tep_db_perform(TABLE_ORDERS_STATUS, $sql_data_array);
			
			$sql_data_array = array('orders_status_id' => $status_id++,
									'language_id' => $portuguese['id'],
									'orders_status_name' => 'Falha');
			tep_db_perform(TABLE_ORDERS_STATUS, $sql_data_array);
			
			$sql_data_array = array('orders_status_id' => $status_id++,
									'language_id' => $portuguese['id'],
									'orders_status_name' => 'Pendente');
			tep_db_perform(TABLE_ORDERS_STATUS, $sql_data_array);
		}
		//************ CREACION DE LOS ESTADOS EN LOS TRES IDIOMAS ************//
	
		tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Habilitar/Deshabilitar', 'MODULE_PAYMENT_PAYU_LATAM_STATUS', 'False', 'Desea habilitar a PayU Latam como pasarela de pago?', '6', '0', 'tep_cfg_select_option(array(\'True\', \'False\'), ', now())");
		
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Merchant ID', 'MODULE_PAYMENT_PAYU_LATAM_MERCHANT_ID', '', 'ID �nico de usuario en PayU Latam', '6', '1', now())");
		
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Account ID', 'MODULE_PAYMENT_PAYU_LATAM_ACCOUNT_ID', '', 'ID de la cuenta en PayU Latam', '6', '2', now())");
		
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('API Key', 'MODULE_PAYMENT_PAYU_LATAM_API_KEY', '', 'Llave que sirve para encriptar la comunicaci�n con PayU Latam', '6', '3', now())");
		
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Gateway URL', 'MODULE_PAYMENT_PAYU_LATAM_GATEWAY_URL', '', 'URL de la pasarela de pago PayU Latam', '6', '4', now())");
	
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Modo Transacciones', 'MODULE_PAYMENT_PAYU_LATAM_TRANSACTION_MODE', 'Test', 'Define si el modo en el que se enviaran las transacciones', '6', '5', 'tep_cfg_select_option(array(\'Live\', \'Test\'), ', now())");
		
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('P�gina de respuesta', 'MODULE_PAYMENT_PAYU_LATAM_RESPONSE_PAGE', '', 'URL de la p�gina mostrada despu�s de finalizar el pago', '6', '6', now())");
		
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('P�gina de confirmaci�n', 'MODULE_PAYMENT_PAYU_LATAM_CONFIRMATION_PAGE', '', 'URL de la p�gina que recibe la respuesta definitiva sobre los pagos', '6', '7', now())");
	}
	
	/*
	 * Borra todos los datos relacionados con el modulo de pago
	 */
	function remove() {
	
      tep_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
    }
	
	/*
	 * Devuelve un arreglo que contiene los nombres de los parametros de configuracion
	 */
	function keys() {
	
      return array('MODULE_PAYMENT_PAYU_LATAM_STATUS', 'MODULE_PAYMENT_PAYU_LATAM_MERCHANT_ID', 'MODULE_PAYMENT_PAYU_LATAM_ACCOUNT_ID', 'MODULE_PAYMENT_PAYU_LATAM_API_KEY', 'MODULE_PAYMENT_PAYU_LATAM_GATEWAY_URL', 'MODULE_PAYMENT_PAYU_LATAM_TRANSACTION_MODE', 'MODULE_PAYMENT_PAYU_LATAM_RESPONSE_PAGE', 'MODULE_PAYMENT_PAYU_LATAM_CONFIRMATION_PAGE');
    }

    function before_process() {
	
      return false;
    }

    function after_process() {
	
      return false;
    }
	
	/*
	 * Construye la peticion POST
	 */
	function process_button() {
	
		global $customer_id, $order, $sendto, $currency;
		$order_id = $this->_create_order();
	
		$description;
		$taxValue = 0;
		$taxReturnBase = 0;
		for ($i=0, $n=sizeof($order->products); $i<$n; $i++) {
			$description .= $order->products[$i]['name'] . ',';
			if ($order->products[$i]['tax'] > 0) {
				$taxValue += $this->format_raw($order->products[$i]['final_price']) * ($order->products[$i]['tax']/100);
				$taxReturnBase += $this->format_raw($order->products[$i]['final_price']);
			}
		}
                trim($description, ',');
                if (strlen($description) > 255){
                    $description = substr($description,0,240).' y otros...';
                }
		$taxValue = number_format($taxValue,2,'.','');
		$taxReturnBase = number_format($taxReturnBase,2,'.','');
		if ($taxValue == 0) $taxReturnBase = 0;
		
		$amount = number_format(($this->format_raw($order->info['total'])),2,'.','');
		
		//$referenceCode = date('Y-m-d H:i:s.u');
		$referenceCode = $order_id;
		$signature = md5(MODULE_PAYMENT_PAYU_LATAM_API_KEY . '~' . MODULE_PAYMENT_PAYU_LATAM_MERCHANT_ID . '~' . $referenceCode . '~' . $amount . '~' . $currency);
		
		$test = 0;
		if (MODULE_PAYMENT_PAYU_LATAM_TRANSACTION_MODE == 'Test') {
			$test = 1;
		}
	
		$process_button_string .= tep_draw_hidden_field('merchantId', MODULE_PAYMENT_PAYU_LATAM_MERCHANT_ID) .
								tep_draw_hidden_field('referenceCode', $referenceCode) .
								tep_draw_hidden_field('description', $description) .
								tep_draw_hidden_field('amount', $amount) .
								tep_draw_hidden_field('tax', $taxValue) .
								tep_draw_hidden_field('taxReturnBase', $taxReturnBase) .
								tep_draw_hidden_field('signature', $signature) .
								tep_draw_hidden_field('accountId', MODULE_PAYMENT_PAYU_LATAM_ACCOUNT_ID) .
								tep_draw_hidden_field('currency', $currency) .
								tep_draw_hidden_field('buyerEmail', $order->customer['email_address']) .
								tep_draw_hidden_field('test', $test) .
								tep_draw_hidden_field('extra1', 'Oscommerce 2.3.3.4') .
								tep_draw_hidden_field('responseUrl', MODULE_PAYMENT_PAYU_LATAM_RESPONSE_PAGE) .
								tep_draw_hidden_field('confirmationUrl', MODULE_PAYMENT_PAYU_LATAM_CONFIRMATION_PAGE) .
								tep_draw_hidden_field('payerFullName', $order->customer['firstname'] . ' ' . $order->customer['lastname']) .
								tep_draw_hidden_field('billingAddress', $order->billing['street_address']) .
								tep_draw_hidden_field('shippingAddress', $order->delivery['street_address']) .
								tep_draw_hidden_field('telephone', $order->customer['telephone']) .
								tep_draw_hidden_field('billingCity', $order->billing['city']) .
								tep_draw_hidden_field('shippingCity', $order->delivery['city']) .
								tep_draw_hidden_field('billingCountry', $order->billing['country']['iso_code_2']) .
								tep_draw_hidden_field('shippingCountry', $order->delivery['country']['iso_code_2']);
								
		return $process_button_string;
	}
    
    /**
     * Guarda la orden en la base de datos segun lo que hacia el archivo cehckout_process.php
     */
    function _create_order() {
      global $customer_id, $order, $languages_id, $order_total_modules;
        
		//************ SE GUARDA LA ORDEN ************//
        $sql_data_array = array('customers_id' => $customer_id,
                                'customers_name' => $order->customer['firstname'] . ' ' . $order->customer['lastname'],
                                'customers_company' => $order->customer['company'],
                                'customers_street_address' => $order->customer['street_address'],
                                'customers_suburb' => $order->customer['suburb'],
                                'customers_city' => $order->customer['city'],
                                'customers_postcode' => $order->customer['postcode'], 
                                'customers_state' => $order->customer['state'], 
                                'customers_country' => $order->customer['country']['title'], 
                                'customers_telephone' => $order->customer['telephone'], 
                                'customers_email_address' => $order->customer['email_address'],
                                'customers_address_format_id' => $order->customer['format_id'], 
                                'delivery_name' => trim($order->delivery['firstname'] . ' ' . $order->delivery['lastname']),
                                'delivery_company' => $order->delivery['company'],
                                'delivery_street_address' => $order->delivery['street_address'], 
                                'delivery_suburb' => $order->delivery['suburb'], 
                                'delivery_city' => $order->delivery['city'], 
                                'delivery_postcode' => $order->delivery['postcode'], 
                                'delivery_state' => $order->delivery['state'], 
                                'delivery_country' => $order->delivery['country']['title'], 
                                'delivery_address_format_id' => $order->delivery['format_id'], 
                                'billing_name' => $order->billing['firstname'] . ' ' . $order->billing['lastname'], 
                                'billing_company' => $order->billing['company'],
                                'billing_street_address' => $order->billing['street_address'], 
                                'billing_suburb' => $order->billing['suburb'], 
                                'billing_city' => $order->billing['city'], 
                                'billing_postcode' => $order->billing['postcode'], 
                                'billing_state' => $order->billing['state'], 
                                'billing_country' => $order->billing['country']['title'], 
                                'billing_address_format_id' => $order->billing['format_id'], 
                                'payment_method' => $order->info['payment_method'], 
                                'date_purchased' => 'now()', 
                                'orders_status' => $order->info['order_status'], 
                                'currency' => $order->info['currency'], 
                                'currency_value' => $order->info['currency_value']);
        tep_db_perform(TABLE_ORDERS, $sql_data_array);
        $insert_id = tep_db_insert_id();
		//************ SE GUARDA LA ORDEN ************//
		
		//************ SE GUARDA LOS ORDER_TOTALS ************//
		$order_totals = array();
          if (is_array($order_total_modules->modules)) {
            reset($order_total_modules->modules);
            while (list(, $value) = each($order_total_modules->modules)) {
              $class = substr($value, 0, strrpos($value, '.'));
              if ($GLOBALS[$class]->enabled) {
                for ($i=0, $n=sizeof($GLOBALS[$class]->output); $i<$n; $i++) {
                  if (tep_not_null($GLOBALS[$class]->output[$i]['title']) && tep_not_null($GLOBALS[$class]->output[$i]['text'])) {
                    $order_totals[] = array('code' => $GLOBALS[$class]->code,
                                            'title' => $GLOBALS[$class]->output[$i]['title'],
                                            'text' => $GLOBALS[$class]->output[$i]['text'],
                                            'value' => $GLOBALS[$class]->output[$i]['value'],
                                            'sort_order' => $GLOBALS[$class]->sort_order);
                  }
                }
              }
            }
          }
		
        for ($i=0, $n=sizeof($order_totals); $i<$n; $i++) {
			$sql_data_array = array('orders_id' => $insert_id,
								  'title' => $order_totals[$i]['title'],
								  'text' => $order_totals[$i]['text'],
								  'value' => $order_totals[$i]['value'], 
								  'class' => $order_totals[$i]['code'], 
								  'sort_order' => $order_totals[$i]['sort_order']);
			tep_db_perform(TABLE_ORDERS_TOTAL, $sql_data_array);
        }
		//************ SE GUARDA LOS ORDER_TOTALS ************//
		
		$customer_notification = (SEND_EMAILS == 'true') ? '1' : '0';
		$sql_data_array = array('orders_id' => $insert_id, 
							  'orders_status_id' => $order->info['order_status'], 
							  'date_added' => 'now()', 
							  'customer_notified' => $customer_notification,
							  'comments' => $order->info['comments']);
		tep_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);

        for ($i=0, $n=sizeof($order->products); $i<$n; $i++) {
			//************ Update products_ordered (for bestsellers list) ************//
			tep_db_query("update " . TABLE_PRODUCTS . " set products_ordered = products_ordered + " . sprintf('%d', $order->products[$i]['qty']) . " where products_id = '" . tep_get_prid($order->products[$i]['id']) . "'");

			$sql_data_array = array('orders_id' => $insert_id, 
								  'products_id' => tep_get_prid($order->products[$i]['id']), 
								  'products_model' => $order->products[$i]['model'], 
								  'products_name' => $order->products[$i]['name'], 
								  'products_price' => $order->products[$i]['price'], 
								  'final_price' => $order->products[$i]['final_price'], 
								  'products_tax' => $order->products[$i]['tax'], 
								  'products_quantity' => $order->products[$i]['qty']);
			tep_db_perform(TABLE_ORDERS_PRODUCTS, $sql_data_array);
			$order_products_id = tep_db_insert_id();
			//************ Update products_ordered (for bestsellers list) ************//

			//************ INSERTA LAS OPCIONES DEL CLIENTE PARA EL PEDIDO ************//
			$attributes_exist = '0';
			$products_ordered_attributes = '';
			if (isset($order->products[$i]['attributes'])) {
				$attributes_exist = '1';
				for ($j=0, $n2=sizeof($order->products[$i]['attributes']); $j<$n2; $j++) {
					if (DOWNLOAD_ENABLED == 'true') {
						$attributes_query = "select popt.products_options_name, poval.products_options_values_name, pa.options_values_price, pa.price_prefix, pad.products_attributes_maxdays, pad.products_attributes_maxcount , pad.products_attributes_filename 
						from " . TABLE_PRODUCTS_OPTIONS . " popt, " . TABLE_PRODUCTS_OPTIONS_VALUES . " poval, " . TABLE_PRODUCTS_ATTRIBUTES . " pa 
						left join " . TABLE_PRODUCTS_ATTRIBUTES_DOWNLOAD . " pad
						on pa.products_attributes_id=pad.products_attributes_id
						where pa.products_id = '" . (int)$order->products[$i]['id'] . "' 
						and pa.options_id = '" . (int)$order->products[$i]['attributes'][$j]['option_id'] . "' 
						and pa.options_id = popt.products_options_id 
						and pa.options_values_id = '" . (int)$order->products[$i]['attributes'][$j]['value_id'] . "' 
						and pa.options_values_id = poval.products_options_values_id 
						and popt.language_id = '" . (int)$languages_id . "' 
						and poval.language_id = '" . (int)$languages_id . "'";
						$attributes = tep_db_query($attributes_query);
					} else {
						$attributes = tep_db_query("select popt.products_options_name, poval.products_options_values_name, pa.options_values_price, pa.price_prefix from " . TABLE_PRODUCTS_OPTIONS . " popt, " . TABLE_PRODUCTS_OPTIONS_VALUES . " poval, " . TABLE_PRODUCTS_ATTRIBUTES . " pa where pa.products_id = '" . (int)$order->products[$i]['id'] . "' and pa.options_id = '" . (int)$order->products[$i]['attributes'][$j]['option_id'] . "' and pa.options_id = popt.products_options_id and pa.options_values_id = '" . (int)$order->products[$i]['attributes'][$j]['value_id'] . "' and pa.options_values_id = poval.products_options_values_id and popt.language_id = '" . (int)$languages_id . "' and poval.language_id = '" . (int)$languages_id . "'");
					}
					$attributes_values = tep_db_fetch_array($attributes);

					$sql_data_array = array('orders_id' => $insert_id, 
											  'orders_products_id' => $order_products_id, 
											  'products_options' => $attributes_values['products_options_name'],
											  'products_options_values' => $attributes_values['products_options_values_name'], 
											  'options_values_price' => $attributes_values['options_values_price'], 
											  'price_prefix' => $attributes_values['price_prefix']);
					tep_db_perform(TABLE_ORDERS_PRODUCTS_ATTRIBUTES, $sql_data_array);

					if ((DOWNLOAD_ENABLED == 'true') && isset($attributes_values['products_attributes_filename']) && tep_not_null($attributes_values['products_attributes_filename'])) {
						$sql_data_array = array('orders_id' => $insert_id, 
												'orders_products_id' => $order_products_id, 
												'orders_products_filename' => $attributes_values['products_attributes_filename'], 
												'download_maxdays' => $attributes_values['products_attributes_maxdays'], 
												'download_count' => $attributes_values['products_attributes_maxcount']);
						tep_db_perform(TABLE_ORDERS_PRODUCTS_DOWNLOAD, $sql_data_array);
					}
					$products_ordered_attributes .= "\n\t" . $attributes_values['products_options_name'] . ' ' . $attributes_values['products_options_values_name'];
				}
			}
			//************ INSERTA LAS OPCIONES DEL CLIENTE PARA EL PEDIDO ************//
        }        
        return $insert_id;
    }
	
	// format prices without currency formatting
    function format_raw($number, $currency_code = '', $currency_value = '') {
	
      global $currencies, $currency;

      if (empty($currency_code) || !$currencies->is_set($currency_code)) {
        $currency_code = $currency;
      }

      if (empty($currency_value) || !is_numeric($currency_value)) {
        $currency_value = $currencies->currencies[$currency_code]['value'];
      }

      return number_format(tep_round($number * $currency_value, $currencies->currencies[$currency_code]['decimal_places']), $currencies->currencies[$currency_code]['decimal_places'], '.', '');
    }

}

?>