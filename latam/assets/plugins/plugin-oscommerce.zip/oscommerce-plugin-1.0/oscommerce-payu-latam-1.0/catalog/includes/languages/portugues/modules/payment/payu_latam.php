<?php

/*
  $Id: PayU Latam 22/04/2014 $

  PayU Latam module payment for Oscommerce 2.3.3.4
  http://www.payulatam.com

  @copyright  Copyright (c) 2012 PayUn Latam
*/

define('MODULE_PAYMENT_PAYU_LATAM_TEXT_TITLE', 'PayU Latam');
define('MODULE_PAYMENT_PAYU_LATAM_TEXT_PUBLIC_TITLE', 'PayU Latam');
define('MODULE_PAYMENT_PAYU_LATAM_TEXT_DESCRIPTION', '<a href="http://payulatam.com/" target="_blank" style="text-decoration: underline; font-weight: bold;">PayU Latam BR</a>');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE', 'Obrigado por seu pagamento!');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE_FAILED', 'Falha na transa��o');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE_REJECTED', 'Transa��o recusada');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE_PENDING', 'Pendente, por favor verifique se o d�bito foi feito pelo banco');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE_APPROVED', 'Transa��o aprovada');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_DATA', 'DADOS DE COMPRA');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_TX_STATE', 'Status da Transa��o');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_TX_ID', 'ID de transa��o');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_REFERENCE', 'Refer�ncia');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_TX_REFERENCE', 'Refer�ncia da transa��o');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_BANK', 'Banco');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_TOTAL_VALUE', 'Valor total');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_CURRENCY', 'Moeda');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_DESC', 'Produto');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_ENTITY', 'Entidade');
define('MODULE_PAYMENT_PAYU_LATAM_ERROR_SIGNATURE', 'A requisi��o � errada, h� um erro na assinatura digital.');
define('MODULE_PAYMENT_PAYU_LATAM_STATUS_APPROVED', 'Aprovado');
define('MODULE_PAYMENT_PAYU_LATAM_STATUS_REJECTED', 'Recusada');
define('MODULE_PAYMENT_PAYU_LATAM_STATUS_FAILED', 'Falha');
define('MODULE_PAYMENT_PAYU_LATAM_STATUS_PENDING', 'Pendente');

?>