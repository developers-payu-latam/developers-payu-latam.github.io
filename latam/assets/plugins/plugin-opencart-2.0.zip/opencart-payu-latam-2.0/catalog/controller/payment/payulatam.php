<?php
class ControllerPaymentPayulatam extends Controller {
  public function index() {
    $this->language->load('payment/payulatam');

    if (!$this->config->get('payulatam_test_mode')) {
    		$data['action'] = $this->config->get('payulatam_production_url');
  		} else {
			$data['action'] = $this->config->get('payulatam_test_url');
		}

    if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/payulatam.tpl')) {
				$this->template = $this->config->get('config_template') . '/template/payment/payulatam.tpl';
    } else {
				$this->template = 'default/template/payment/payulatam.tpl';
    }

    // get button text
    $data['text_submit'] = $this->language->get('text_submit');

    $this->load->model('checkout/order');

		$order = $this->model_checkout_order->getOrder($this->session->data['order_id']);

    $currency = $this->currency->getCode();

    $referenceCode = $order["order_id"];

    $subTotal = $this->currency->format($this->cart->getSubTotal(), $currency, false, false);

    $total = $this->currency->format($order['total'], $currency, false, false);

    $baseIva = 0;

    $iva = 0;

    $taxes = $this->cart->getTaxes();

    foreach ($taxes as $key => $value) {
      $iva += $this->currency->format($value, $currency, false, false);
    }

    if($iva != 0) {
      $baseIva = $subTotal;
    }

    $firma = md5($this->config->get('payulatam_api_key').
            "~".$this->config->get('payulatam_merchant_id').
            "~".$referenceCode.
            "~".$total.
            "~".$currency);

    $data['formData'] = array( // $formData
      "merchantId" => $this->config->get('payulatam_merchant_id'),
      "accountId" => $this->config->get('payulatam_account_id'),
      "referenceCode" => $referenceCode,
      "description" => "sale ". $referenceCode,
      "amount" => $total,
      "currency" => $currency,
      "tax"      => $iva,
      "test"     => $this->config->get('payulatam_test_mode'),
      "taxReturnBase" => $baseIva,
      "signature" => $firma,
      "buyerEmail" => $order['email'],
      "responseUrl" => $this->url->link('payment/payulatam/response', '', 'SSL'),
      "confirmationUrl" => $this->url->link('payment/payulatam/confirmation', '', 'SSL'),
      "extra1" => "OPENCART 2.0.1.x",
      "billingAddress" => $order['payment_address_1'],
      "billingCity" => $order['payment_city'],
      "billingCountry" => $order['payment_iso_code_2'],
      "shippingAddress" => $order['shipping_address_1'],
      "shippingCity" => $order['shipping_city'],
      "shippingCountry" => $order['shipping_iso_code_2'],
      "buyerFullName" => $order['payment_firstname'] . " " . $order['payment_lastname']
    );
    
    return $this->load->view($this->template, $data);
  }

  public function response() {
    if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/payulatam_response.tpl')) {
				$this->template = $this->config->get('config_template') . '/template/payment/payulatam_response.tpl';
    } else {
				$this->template = 'default/template/payment/payulatam_response.tpl';
    }

		$data['header'] = $this->load->controller('common/header');
    $data['footer'] = $this->load->controller('common/footer');
    $data['column_left'] = $this->load->controller('common/column_left');

    $data["values"] = $this->_getResponsePayuValues();
    $amount = number_format($data["values"]['TX_VALUE'], 1, '.', '');

    $tx_state = $data["values"]['transactionState'];
    $firma = md5($this->config->get('payulatam_api_key').
            "~".$data["values"]['merchantId'].
            "~".$data["values"]['referenceCode'].
            "~".$amount.
            "~".$data["values"]['currency'].
            "~".$tx_state);

    if($firma != $data["values"]['signature']){
      $data["error"] = true;
    } else {
      $data["error"] = false;

		// confirm the order with status pending
		$this->load->model('checkout/order');
    $order_id=$this->session->data['order_id'];
    $order_info = $this->model_checkout_order->getOrder($order_id);
   
    if($order_info['order_status_id'] == 0){
		  $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payulatam_pending_transaction'));
    }
    if($tx_state == '4') {
      $this->_clearCart();
    }
    }
    $this->response->setOutput($this->load->view($this->template, $data));
  }

  function _clearCart(){

    $this->cart->clear();
    unset($this->session->data['shipping_method']);
    unset($this->session->data['shipping_methods']);
    unset($this->session->data['payment_method']);
    unset($this->session->data['payment_methods']);
    unset($this->session->data['guest']);
    unset($this->session->data['comment']);
    unset($this->session->data['order_id']);
    unset($this->session->data['coupon']);
    unset($this->session->data['reward']);
    unset($this->session->data['voucher']);
    unset($this->session->data['vouchers']);
    unset($this->session->data['totals']);
    if (isset($this->session->data['customer_id'])) {
      $customer_id = $this->session->data['customer_id'];
      $this->db->query("UPDATE `" . DB_PREFIX . "customer` SET cart = '' WHERE customer_id = '" . (int)$customer_id . "'");
      $this->session->data['cart'] = array();
    }

  }

  function _getResponsePayuValues() {

		$fields = array(
    	"merchantId" => "usuario_id",
    	"merchant_name" => "usuario_nombre",
    	"merchant_address" => "usuario_direccion",
    	"telephone" => "telefono",
    	"merchant_url" => "usuario_url",
    	"transactionState" => "estado",
    	"lapTransactionState" => "estado_lap",
    	"message" => "mensaje",
    	"referenceCode" => "ref_venta",
    	"reference_pol" => "ref_pol",
    	"transactionId" => "transaccion_id",
    	"description" => "descripcion",
    	"trazabilityCode" => "trazability_code",
    	"cus" => "cus",
    	"orderLanguage" => "idioma",
    	"extra1" => "extra1",
    	"extra2" => "extra2",
    	"extra3" => "extra3",
    	"signature" => "firma",
    	"polResponseCode" => "codigo_respuesta_pol",
    	"lapResponseCode" => "codigo_respuesta_lap",
    	"risk" => "riesgo",
    	"polPaymentMethod" => "medio_pago",
    	"lapPaymentMethod" => "medio_pago_lap",
    	"polPaymentMethodType" => "tipo_medio_pago",
    	"lapPaymentMethodType" => "tipo_medio_pago_lap",
    	"installmentsNumber" => "cuotas",
    	"TX_VALUE" => "valor",
    	"TX_TAX" => "iva",
    	"currency" => "moneda",
    	"lng" => "lng",
    	"pseCycle" => "ciclo_pse",
    	"buyerEmail" => "emailComprador",
    	"pseBank" => "banco_pse",
    	"pseReference1" => "pseReferencia1",
			"pseReference2" => "pseReferencia2",
    	"pseReference3" => "pseReferencia3",
    	"authorizationCode" => "codigo_autorizacion",
    	"TX_ADMINISTRATIVE_FEE" => "tarifa_administrativa",
    	"TX_TAX_ADMINISTRATIVE_FEE" => "iva_tarifa_administrativa",
    	"TX_TAX_ADMINISTRATIVE_FEE_RETURN_BASE" => "base_tarifa_administrativa",
    	"processingDate" => "fecha_procesamiento",
    	"cc_number" => "numero_visible",
    	"cc_holder" => "tarjeta_habiente",
    	"request_number" => "numero_pedido",
    	"processing_date_time" => "fecha_hora_procesamiento",
    	"action_code_description" => "descripcion_codigo_accion"
  	);

		$values = array();

  	foreach($fields as $key => $value) {
    	$val = ( isset($_REQUEST[$key]) )? $_REQUEST[$key] : ((isset($_REQUEST[$value]) )? $_REQUEST[$value] : null);
    	if(isset($val)) {
      	$values[$key] = $val;
    	}
  	}

		return $values;

	}

  public function confirmation() {

    $this->load->library('log');

    $logger = new Log('payulatam_ocplugin.log');
    $logger->write('Confirmation process started.');


    $values = $this->_getConfirmationPayuValues();

    $order_id = $values['reference_sale'];

    $this->load->model('checkout/order');

		$order_info = $this->model_checkout_order->getOrder($order_id);

    $result = $this->_validatePayment($logger, $values);

    if(!$result) {
     $logger->write('dont pass validation');
     error_log('dont pass validation'); 
			return FALSE;

		} else {

      $order_status_id = $result['order_status'];

     
                $this->model_checkout_order->addOrderHistory($order_id, $order_status_id);
    
    }

  }

  function _validatePayment($logger, $values) {
		$result = array();
		$result['customer_notified'] = 1;

		// validate signature

		// if second decimal of value is zero we round to 1 decimal
		$val = number_format($values['value'], 1, '.', '');
		$signMd5 = $this->_getSignMd5($values, $val);

		$logger->write('sign ' . $values['sign']);
		$logger->write('signMd5 ' . $signMd5);

		if(strtoupper($values['sign']) != strtoupper($signMd5) ){
			// try with two
			$val = number_format($values['value'], 2, '.', '');
			$signMd5 = $this->_getSignMd5($values, $val);

			if(strtoupper($values['sign']) != strtoupper($signMd5) ) {
				return FALSE;
			}
		}

		// validate transaction state
		$trxState = $values['state_pol'];

		if($trxState == '6' || $trxState == '5' || $trxState == '104') {
			$result['order_status'] = $this->config->get('payulatam_declined_transaction');
		} elseif($trxState == '4') {
			$result['order_status'] = $this->config->get('payulatam_approved_transaction');
      $this->cart->clear();
		} else {
			$result['order_status'] = $this->config->get('payulatam_pending_transaction');
		}

		$result['comments'] = '';

		return $result;
	}


	function _getSignMd5($values, $val) {
		return md5($this->config->get('payulatam_api_key') . '~' . $values['merchant_id'] . '~' . $values['reference_sale'] . '~' .
			$val . '~' . $values['currency'] . '~' . $values['state_pol']);
	}

  function _getConfirmationPayuValues() {

		$fields = array(
    	"nickname_buyer" => "nickname_comprador",
    	"nickname_seller" => "nickname_vendedor",
    	"transaction_id" => "transaccion_id",
    	"merchant_id" => "usuario_id",
    	"date" => "fecha",
    	"transaction_date" => "fecha_transaccion",
    	"payment_request_state" => "estado_transaccion",
    	"sign" => "firma",
    	"test" => "prueba",
    	"reference_sale" => "ref_venta",
    	"reference_pol" => "ref_pol",
    	"airline_code" => "codigo_aerolinea",
    	"description" => "descripcion",
    	"ip" => "ip",
    	"extra1" => "extra1",
    	"extra2" => "extra2",
    	"attempts" => "intentos",
			"currency" => "moneda",
    	"state_pol" => "estado_pol",
    	"email_buyer" => "email_comprador",
    	"exchange_rate" => "tasa_cambio",
    	"value" => "valor",
    	"additional_value" => "valorAdicional",
    	"tax" => "iva",
    	"error_message_bank" => "mensaje_error_banco",
    	"error_code_bank" => "codigo_error_banco",
    	"pse_reference1" => "pse_referencia1",
    	"pse_reference2" => "pse_referencia2",
			"pse_reference3" => "pse_referencia3",
    	"risk" => "riesgo",
    	"response_code_pol" => "codigo_respuesta_pol",
    	"response_message_pol" => "mensaje_respuesta_pol",
    	"billing_address" => "direccionCobro",
    	"billing_city" => "ciudadCobro",
    	"billing_country" => "paisCobro",
    	"shipping_address" => "direccionEnvio",
			"shipping_city" => "ciudadEnvio",
    	"shipping_country" => "paisEnvio",
    	"phone" => "telefono",
    	"office_phone" => "telefonoOficina",
    	"cus" => "cus",
    	"pse_bank" => "banco_pse",
    	"customer_number" => "numeroCliente",
    	"bank_id" => "banco_id",
    	"payment_method_id" => "medio_pago_id",
    	"payment_method" => "medio_pago",
    	"payment_method_type" => "tipo_medio_pago",
    	"installments_number" => "cuotas",
			"account_number_ach" => "numero_cuenta_deb_ach",
			"account_type_ach" => "tipo_cuenta_deb_ach",
			"bank_id_ach" => "banco_id_deb_ach",
			"administrative_fee" => "tarifa_administrativa",
			"administrative_fee_tax" => "iva_tarifa_administrativa",
			"administrative_fee_base" => "base_tarifa_administrativa",
			"commision_pol" => "comision_pol",
			"commision_pol_currency" => "moneda_comision_pol",
			"transaction_bank_id" => "transaccion_banco_id",
			"authorization_code" => "codigo_autorizacion"
  	);

		$values = array();

  	foreach($fields as $key => $value) {
    	$val = ( isset($_REQUEST[$key]) )? $_REQUEST[$key] : (( isset($_REQUEST[$value]) )? $_REQUEST[$value] : null);
    	if(isset($val)) {
      	$values[$key] = $val;
    	}
  	}

		return $values;
  }

}
?>
