<?php
class ControllerPaymentPayulatam extends Controller {
  private $error = array();

  public function index() {

    $this->load->language('payment/payulatam'); // Load the language file

    $this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

    $token = 'token=' . $this->session->data['token'];

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
      
			$this->model_setting_setting->editSetting('payulatam', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/payment', $token, 'SSL'));
		}

    $fields = array('production_url', 'test_url', 'test_mode', 'merchant_id',
        'account_id', 'api_key', 'approved_transaction', 'pending_transaction',
        'declined_transaction', 'min_amount', 'status');

    $labels = array('heading_title','text_payment','text_success', 
        'err_permission', 'text_home', 'heading_title','button_save',
        'button_cancel', 'text_yes', 'text_no', 'text_enabled', 'text_disabled');

    foreach (array_merge($fields, $labels) as $value) {
      $data[$value] = $this->language->get($value);
    }

    foreach ($fields as $value) {
      $attribute = 'payulatam_' . $value;
      if (isset($this->request->post[$attribute])) {
        $data[$attribute] = $this->request->post[$attribute];
      } else {
        $data[$attribute] = $this->config->get($attribute);
      }
    }

    $links_map = array('text_home' => 'common/home',
        'text_payment' => 'extension/payment',
        'heading_title' => 'payment/payulatam');

    $data['breadcrumbs'] = array();
    foreach ($links_map as $key => $value) {
      array_push($data['breadcrumbs'], array('text' => $data[$key],
          'href' => $this->url->link($value, $token, 'SSL')));
    }

    $data['action'] = $this->url->link('payment/payulatam', $token, 'SSL');

		$data['cancel'] = $this->url->link('extension/payment', $token, 'SSL');

    $this->load->model('localisation/order_status');

		$data['status_list'] =
            $this->model_localisation_order_status->getOrderStatuses();
    
    $this->template = 'payment/payulatam.tpl';

		$data['header'] = $this->load->controller('common/header');
    $data['footer'] = $this->load->controller('common/footer');
    $data['column_left'] = $this->load->controller('common/column_left');

    $this->response->setOutput($this->load->view($this->template, $data));
  }

  private function validate() {
		return true;
	}
}
?>
