package com.dineromail.blackberry.model;

public interface PaymentMethod {

}
