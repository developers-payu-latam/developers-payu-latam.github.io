//
//  RootViewController.h
//  LibTest
//
//  Created on 9/12/11.
//  Copyright 2011 DineroMail. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {
}

@end
