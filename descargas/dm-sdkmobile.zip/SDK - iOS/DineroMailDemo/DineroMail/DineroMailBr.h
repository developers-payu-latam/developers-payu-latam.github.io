//
//  DineroMailBr.h
//  PostWebView
//
//  Created on 9/9/11.
//  Copyright 2011 DineroMail. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DineroMail.h"

@interface DineroMailBr : DineroMail {

}

@end
