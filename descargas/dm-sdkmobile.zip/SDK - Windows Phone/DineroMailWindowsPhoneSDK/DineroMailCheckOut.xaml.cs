﻿namespace DineroMailWindowsPhoneSDK
{
    using System;
    using System.Linq;
    using System.Text;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Navigation;

    public partial class DineroMailCheckOut : UserControl
    {
        public bool ShowProgress
        {
            get
            {
                return this.showProgress;
            }
            
            set
            {
                this.showProgress = value;
            }
        }

        public OperationStatus OperationStatus { get; set; }

        private const string CheckOutUrl = "https://checkout.dineromail.com";

        private const string ResultOk = "OK";

        private const string ResultPending = "PENDING";

        private const string ResultError = "ERROR";

        private bool showProgress = true;

        #region Event Handlers

        public event EventHandler CheckOutProcessFinished;

        void CheckOutWebBrowser_Navigating(object sender, Microsoft.Phone.Controls.NavigatingEventArgs e)
        {
            performanceProgressBar.IsIndeterminate = this.ShowProgress;

            if (!System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable())
            {
                this.NavigationFailed(e);
            }
        }

        void CheckOutWebBrowser_Navigated(object sender, NavigationEventArgs e)
        {
            this.SetOperationStatus();

            if (CheckOutProcessFinished != null && this.OperationStatus != OperationStatus.Undefined)
            {
                CheckOutProcessFinished(this, EventArgs.Empty);
            }
        }

        
        private void CheckOutWebBrowser_LoadCompleted(object sender, NavigationEventArgs e)
        {
            this.CheckOutWebBrowser.Visibility = Visibility.Visible;

            this.ShowGrid();

            performanceProgressBar.IsIndeterminate = false;
        }

        private void CheckOutWebBrowser_NavigationFailed(object sender, NavigationFailedEventArgs e)
        {
            this.NavigationFailed(e);
        }

        private void NavigationFailed(EventArgs e)
        {
            this.OperationStatus = OperationStatus.NavigationFailed;

            this.performanceProgressBar.IsIndeterminate = false;

            this.CheckOutProcessFinished(this, e);
        }

        #endregion Event Handlers

        public DineroMailCheckOut()
        {
            InitializeComponent();
        }

        public void ProceedToCheckOut(Payment payment)
        {
            Encoding encode = new UTF8Encoding();
            byte[] post = encode.GetBytes(this.GetCheckOutParameters(payment));
            const string PostHeaders = "Content-Type: application/x-www-form-urlencoded";

            CheckOutWebBrowser.Navigate(new Uri(CheckOutUrl, UriKind.Absolute), post, PostHeaders);
        }

        private string GetCheckOutParameters(Payment payment)
        {
            var parameters = new StringBuilder();

            this.GetBaseParameters(payment, parameters);

            this.GetRedirectUrlParameters(payment, parameters);

            this.GetDisplayOptionsParameters(payment, parameters);

            this.GetPaymentMethodParameters(payment, parameters);

            this.GetProductsParameters(payment, parameters);

            this.GetAdditionalVarsParameters(payment, parameters);

            this.GetBuyerParameters(payment, parameters);

            this.GetAdditionalChargesParameters(payment, parameters);

            this.GetStepsParameters(payment, parameters);

            return parameters.ToString();
        }

        private void GetStepsParameters(Payment payment, StringBuilder parameters)
        {
            if (payment.ExpandedStepPaymentMethods)
            {
                parameters.Append("&expanded_step_PM=1");
            }

            if (payment.ExpandedStepAdditionalData)
            {
                parameters.Append("&expanded_step_AD=1");
            }

            if (payment.ExpandedStepShipping)
            {
                parameters.Append("&expanded_step_SC=1");
            }

            if (payment.ExpandedSaleDetail)
            {
                parameters.Append("&expanded_sale_detail=1");
            }
        }

        private void GetAdditionalChargesParameters(Payment payment, StringBuilder parameters)
        {
            if (payment.AdditionalFixedCharge > 0)
            {
                parameters.Append("&additional_fixed_charge=" + payment.AdditionalFixedCharge.GetFormattedAmount());
            }

            if (payment.AdditionalVariableCharge > 0)
            {
                parameters.Append("&additional_variable_charge=" + payment.AdditionalVariableCharge.GetFormattedAmount());
            }

            if (payment.AdditionalFixedChargeCurrency != Currency.NotSpecified)
            {
                parameters.Append("&additional_fixed_charge_currency=" + payment.AdditionalFixedChargeCurrency.GetStringValue());
            }
        }

        private void GetBuyerParameters(Payment payment, StringBuilder parameters)
        {
            if (payment.Buyer != null)
            {
                parameters.Append("&buyer_name=" + payment.Buyer.Name);

                parameters.Append("&buyer_lastname=" + payment.Buyer.LastName);

                if (payment.Buyer.Sex != Sex.NotSpecified)
                {
                    parameters.Append("&buyer_sex=" + payment.Buyer.Sex.GetStringValue());
                }

                if (payment.Buyer.DocumentType != DocumentType.NotSpecified)
                {
                    parameters.Append("&buyer_document_type=" + payment.Buyer.DocumentType.GetStringValue());
                }

                parameters.Append("&buyer_document_number=" + payment.Buyer.DocumentNumber);

                parameters.Append("&buyer_email=" + payment.Buyer.Email);

                parameters.Append("&buyer_phone=" + payment.Buyer.Phone);

                parameters.Append("&buyer_phone_extension=" + payment.Buyer.PhoneExtension);

                parameters.Append("&buyer_zip_code=" + payment.Buyer.ZipCode);

                parameters.Append("&buyer_street=" + payment.Buyer.Street);

                parameters.Append("&buyer_number=" + payment.Buyer.Number);

                parameters.Append("&buyer_complement=" + payment.Buyer.Complement);

                parameters.Append("&buyer_city=" + payment.Buyer.City);

                parameters.Append("&buyer_state=" + payment.Buyer.State);

                if (payment.Buyer.Country != BuyerCountry.NotSpecified)
                {
                    parameters.Append("&buyer_country=" + payment.Buyer.Country.GetStringValue());
                }
            }
        }

        private void GetAdditionalVarsParameters(Payment payment, StringBuilder parameters)
        {
            if (payment.AdditionalVars != null)
            {
                int additionalVarIndex = 1;
                foreach (AdditionalVar additionalVar in payment.AdditionalVars)
                {
                    parameters.Append("&additional_var_description_" + additionalVarIndex + "=" + additionalVar.Description);

                    parameters.Append("&additional_var_value_" + additionalVarIndex + "=" + additionalVar.Value);

                    parameters.Append(
                        "&additional_var_visible_" + additionalVarIndex + "=" + (additionalVar.IsVisible ? "1" : "0"));

                    parameters.Append(
                        "&additional_var_required_" + additionalVarIndex + "=" + (additionalVar.IsRequired ? "1" : "0"));

                    additionalVarIndex++;
                }
            }
        }

        private void GetProductsParameters(Payment payment, StringBuilder parameters)
        {
            if (payment.Products != null)
            {
                int productIndex = 1;

                foreach (Product product in payment.Products)
                {
                    parameters.Append("&item_name_" + productIndex + "=" + product.Name);

                    if (!string.IsNullOrWhiteSpace(product.Code))
                    {
                        parameters.Append("&item_code_" + productIndex + "=" + product.Code);
                    }

                    parameters.Append("&item_quantity_" + productIndex + "=" + product.Quantity);

                    parameters.Append("&item_ammount_" + productIndex + "=" + product.Amount.GetFormattedAmount());

                    parameters.Append("&item_currency_" + productIndex + "=" + product.Currency.GetStringValue());

                    parameters.Append("&shipping_type_" + productIndex + "=" + (int)product.ShippingType);

                    if (product.Weight != Weight.NotSpecified)
                    {
                        parameters.Append("&weight_" + productIndex + "=" + product.Weight.GetStringValue());
                        parameters.Append("&item_weight_" + productIndex + "=" + product.WeightValue.GetFormattedAmount());
                    }

                    if (product.ShippingCurrency != Currency.NotSpecified)
                    {
                        parameters.Append(
                            "&shipping_currency_" + productIndex + "=" + product.ShippingCurrency.GetStringValue());
                    }

                    if (product.ShippingCostDefault > 0)
                    {
                        parameters.Append(
                            "&shipping_cost_1_" + productIndex + "=" + product.ShippingCostDefault.GetFormattedAmount());
                    }

                    if (product.ShippingCostTwo > 0)
                    {
                        parameters.Append(
                            "&shipping_cost_2_" + productIndex + "=" + product.ShippingCostTwo.GetFormattedAmount());
                    }

                    productIndex++;
                }
            }
        }

        private void GetPaymentMethodParameters(Payment payment, StringBuilder parameters)
        {
            if (payment.AvailablePaymentMethods != null && payment.AvailablePaymentMethods.Any(x => x.PaymentMethod != PaymentMethod.NotSpecified))
            {
                foreach (AvailablePaymentMethod availablePaymentMethod in payment.AvailablePaymentMethods)
                {
                    if (availablePaymentMethod.PaymentMethod != PaymentMethod.NotSpecified)
                    {
                        parameters.Append("&payment_method_available=" + availablePaymentMethod.PaymentMethod.GetStringValue());

                        if (availablePaymentMethod.AvailableInstalments != null
                            && availablePaymentMethod.AvailableInstalments.Count > 0)
                        {
                            foreach (int instalment in availablePaymentMethod.AvailableInstalments)
                            {
                                parameters.Append("," + instalment);
                            }
                        }

                        parameters.Append(";");
                    }
                }

                parameters.Remove(parameters.Length - 1, 1);
            }

            if (payment.DefaultPaymentMethod != PaymentMethod.NotSpecified)
            {
                parameters.Append("&payment_method_1=" + payment.DefaultPaymentMethod);
            }
        }

        private void GetDisplayOptionsParameters(Payment payment, StringBuilder parameters)
        {
            if (payment.BuyerCanAddMessage)
            {
                parameters.Append("&buyer_message=1");
            }

            if (payment.BuyerCanChangeQuantity)
            {
                parameters.Append("&change_quantity=1");
            }

            if (payment.DisplayShipping)
            {
                parameters.Append("&display_shipping=1");
            }

            if (payment.DisplayAdditionalCharge)
            {
                parameters.Append("&display_additional_charge=1");
            }
        }

        private void GetRedirectUrlParameters(Payment payment, StringBuilder parameters)
        {
            if (!string.IsNullOrWhiteSpace(payment.OkUrl))
            {
                parameters.Append("&ok_url=" + payment.OkUrl);
            }

            if (!string.IsNullOrWhiteSpace(payment.ErrorUrl))
            {
                parameters.Append("&error_url=" + payment.ErrorUrl);
            }

            if (!string.IsNullOrWhiteSpace(payment.PendingUrl))
            {
                parameters.Append("&pending_url=" + payment.PendingUrl);
            }
        }

        private void GetBaseParameters(Payment payment, StringBuilder parameters)
        {
            parameters.Append("merchant=" + payment.Merchant);

            parameters.Append("&tool=button");

            if (payment.Country != Country.NotSpecified)
            {
                parameters.Append("&country_id=" + (int)payment.Country);
            }

            if (!string.IsNullOrWhiteSpace(payment.SellerName))
            {
                parameters.Append("&seller_name=" + payment.SellerName);
            }

            if (payment.Language != DineroMailWindowsPhoneSDK.Language.NotSpecified)
            {
                parameters.Append("&language=" + payment.Language.GetStringValue());
            }

            if (payment.TransactionId != 0)
            {
                parameters.Append("&transaction_id=" + payment.TransactionId);
            }

            if (payment.Currency != Currency.NotSpecified)
            {
                parameters.Append("&currency=" + payment.Currency.GetStringValue());
            }
        }

        private void SetOperationStatus()
        {
            this.OperationStatus = this.GetOperationStatusFromUrl();

            if (this.OperationStatus == OperationStatus.Undefined)
            {
                this.OperationStatus = this.GetOperationStatusFromResult();

                if (this.OperationStatus == OperationStatus.Undefined)
                {
                    this.OperationStatus = this.GetOperationStatusFromHtmlTitle();
                }
            }
        }

        private OperationStatus GetOperationStatusFromUrl()
        {
            if (CheckOutWebBrowser.Source.AbsolutePath.ToLower().EndsWith("/error"))
            {
                return OperationStatus.Error;
            }

            if (CheckOutWebBrowser.Source.AbsolutePath.ToLower().EndsWith("/cancel"))
            {
                return OperationStatus.Cancel;
            }

            return OperationStatus.Undefined;
        }

        private OperationStatus GetOperationStatusFromResult()
        {
            string currentHtml = this.CheckOutWebBrowser.SaveToString();

            int resultStatusIndex = currentHtml.IndexOf("ResultStatus");

            if (resultStatusIndex == -1)
            {
                return OperationStatus.Undefined;
            }

            int openingValueIndex = currentHtml.IndexOf("value", resultStatusIndex);
            int closingValueIndex = currentHtml.IndexOf("\"", openingValueIndex + 7);

            if (openingValueIndex == -1 || closingValueIndex == -1)
            {
                return OperationStatus.Undefined;
            }

            string resultStatus = currentHtml.Substring(openingValueIndex + 7, closingValueIndex - openingValueIndex - 7);

            if (!string.IsNullOrEmpty(resultStatus))
            {
                if (resultStatus == ResultOk)
                {
                    return OperationStatus.Ok;
                }

                if (resultStatus == ResultPending)
                {
                    return OperationStatus.Pending;
                }

                if (resultStatus == ResultError)
                {
                    return OperationStatus.Error;
                }
            }

            return OperationStatus.Undefined;
        }

        private OperationStatus GetOperationStatusFromHtmlTitle()
        {
            string currentHtml = this.CheckOutWebBrowser.SaveToString();

            const string OpeningHtmlTag = "<title>";
            const string ClosingHtmlTag = "</title>";

            int openingTitleIndex = currentHtml.IndexOf(OpeningHtmlTag, StringComparison.Ordinal);
            int closingTitleIndex = currentHtml.IndexOf(ClosingHtmlTag, openingTitleIndex, StringComparison.Ordinal);

            if (openingTitleIndex == -1 || closingTitleIndex == -1)
            {
                return OperationStatus.Undefined;
            }

            string resultMessage = currentHtml.Substring(openingTitleIndex + OpeningHtmlTag.Length, closingTitleIndex - openingTitleIndex - ClosingHtmlTag.Length);

            if (resultMessage.Contains("success") || resultMessage.Contains("exitosa") || resultMessage.Contains("concretizada"))
            {
                return OperationStatus.Ok;
            }

            if (resultMessage.Contains("pending") || resultMessage.Contains("pendiente") || resultMessage.Contains("pendente"))
            {
                return OperationStatus.Pending;
            }

            if (resultMessage.Contains("cancel"))
            {
                return OperationStatus.Cancel;
            }

            if (resultMessage.Contains("erro"))
            {
                return OperationStatus.Error;
            }

            return OperationStatus.Undefined;
        }

        private void ShowGrid()
        {
            this.ContentGrid.RowDefinitions[0].Height = new GridLength(0, GridUnitType.Auto);
            this.ContentGrid.RowDefinitions[1].Height = new GridLength(1, GridUnitType.Star);
        }
    }
}
