﻿using System;

namespace DineroMailWindowsPhoneSDK
{
    using System.Globalization;
    using System.Reflection;

    public static class ExtensionMethods
    {
         public static string GetStringValue(this Enum value) {
            // Get the type
            Type type = value.GetType();

            // Get fieldinfo for this type
            FieldInfo fieldInfo = type.GetField(value.ToString());

            // Get the stringvalue attributes
            StringValueAttribute[] attribs = fieldInfo.GetCustomAttributes(typeof(StringValueAttribute), false) as StringValueAttribute[];

            // Return the first if there was a match.
            return attribs.Length > 0 ? attribs[0].StringValue : null;
        }

        public static string GetFormattedAmount(this float value)
        {
            string stringValue = (value * 100).ToString(CultureInfo.InvariantCulture);
            int decimalSeparatorIndex = stringValue.IndexOf(CultureInfo.InvariantCulture.NumberFormat.CurrencyDecimalSeparator);
            
            if (decimalSeparatorIndex > -1)
            {
                stringValue = stringValue.Remove(decimalSeparatorIndex);
            }

            stringValue.Replace(CultureInfo.InvariantCulture.NumberFormat.CurrencyGroupSeparator, string.Empty);

            return stringValue;
        }
    }
}
