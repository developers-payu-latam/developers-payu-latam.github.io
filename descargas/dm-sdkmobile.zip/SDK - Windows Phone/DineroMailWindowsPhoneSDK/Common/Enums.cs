﻿namespace DineroMailWindowsPhoneSDK
{
    public enum OperationStatus
    {
        Undefined,
        Ok,
        Pending,
        Cancel,
        Error,
        NavigationFailed
    }

    public enum Tool
    {
        [StringValue("")] NotSpecified,
        [StringValue("button")] Button,
        [StringValue("cart")] Cart
    }

    public enum Country
    {
        NotSpecified = 0,
        Argentina = 1,
        Brazil = 2,
        Chile = 3,
        Mexico = 4
    }

    public enum Language
    {
        [StringValue("")] NotSpecified,
        [StringValue("es")] Spanish,
        [StringValue("en")] English,
        [StringValue("pt")] Portuguese
    }

    public enum Sex
    {
        [StringValue("")] NotSpecified,
        [StringValue("m")] Male,
        [StringValue("f")] Female
    }

    public enum BuyerCountry
    {
        [StringValue("")] NotSpecified,
        [StringValue("arg")] Argentina,
        [StringValue("bra")] Brazil,
        [StringValue("chl")] Chile,
        [StringValue("mex")] Mexico
    }

    public enum DocumentType
    {
        [StringValue("")] NotSpecified,
        [StringValue("cpf")] Cpf,
        [StringValue("cnpj")] Cnpj,
        [StringValue("rut")] Rut,
        [StringValue("dni")] Dni,
        [StringValue("cuil")] Cuil,
        [StringValue("cuit")] Cuit,
        [StringValue("le")] Le,
        [StringValue("lc")] Lc,
        [StringValue("rfc")] Rfc,
        [StringValue("curp")] Curp,
        [StringValue("ife")] Ife,
        [StringValue("lic")] Lic
    }

    public enum Currency
    {
        [StringValue("")] NotSpecified,
        [StringValue("ars")] Ars,
        [StringValue("mxn")] Mxn,
        [StringValue("clp")] Clp,
        [StringValue("usd")] Usd,
        [StringValue("brl")] Brl
    }

    public enum Weight
    {
        [StringValue("")] NotSpecified,
        [StringValue("kg")] Kg,
        [StringValue("lb")] Lb
    }

    public enum ShippingType
    {
        NotSpecified,
	    FixedCost,
	    FixedQuantityCost,
	    Weighted
    }

    public enum PaymentMethod
    {
        [StringValue("")] NotSpecified,
        [StringValue("all")] All,
	    [StringValue("ar_amex")] ArgAmex,
	    [StringValue("ar_argencard")] ArgArgencard,
	    [StringValue("ar_banktransfer")] ArgBankTransfer,
	    [StringValue("ar_bapropago")] ArgBaproPago,
	    [StringValue("ar_cabal")] ArgCabal,
	    [StringValue("ar_cobroexpress")] ArgCobroExpress,
	    [StringValue("ar_dm")] ArgDineroMailFunds,
	    [StringValue("ar_italcred")] ArgItalcred,
        [StringValue("ar_master")] ArgMastercard,
	    [StringValue("ar_pagofacil")] ArgPagoFacil,
	    [StringValue("ar_rapipago")] ArgRapiPago,
	    [StringValue("ar_tnaranja")] ArgTarjetaNaranja,
	    [StringValue("ar_tshopping")] ArgTarjetaShopping,
	    [StringValue("ar_visa")] ArgVisa,
        [StringValue("br_amex")] BraAmex,
	    [StringValue("br_aura")] BraAura,
	    [StringValue("br_visa")] BraVisa,
	    [StringValue("br_oipaggo")] BraOiPaggo,
	    [StringValue("br_master")] BraMastercard,
	    [StringValue("br_hipercard")] BraHipercard,
	    [StringValue("br_dm")] BraDineroMailFunds,
	    [StringValue("br_diners")] BraDiners,
	    [StringValue("br_bbancario")] BraBoletoBancario,
	    [StringValue("br_bco_brasil_dd")] BraBancoDoBrasilDirectDebit,
	    [StringValue("br_bco_bradesco_dd")] BraBancoDoBradescoDirectDebit,
        [StringValue("cl_visa")] ChlVisa,
	    [StringValue("cl_servipag")] ChlServipag,
	    [StringValue("cl_ripley")] ChlRipley,
	    [StringValue("cl_presto")] ChlPresto,
	    [StringValue("cl_master")] ChlMastercard,
	    [StringValue("cl_magna")] ChlMagna,
	    [StringValue("cl_dm")] ChlDineroMailFunds,
	    [StringValue("cl_diners")] ChlDiners,
	    [StringValue("cl_amex")] ChlAmex,
        [StringValue("mx_scotiabank_tc")] MexScotiabankCreditCard,
	    [StringValue("mx_scotiabank_tb")] MexScotiabankBankTransfer,
	    [StringValue("mx_scotiabank_dr")] MexScotiabankReferenceDeposit,
	    [StringValue("mx_santander_td")] MexSantanderDebitCard,
	    [StringValue("mx_santander_tc")] MexSantanderCreditCard,
	    [StringValue("mx_santander_tb")] MexSantanderBankTransfer,
	    [StringValue("mx_santander_dr")] MexSantanderReferenceDeposit,
	    [StringValue("mx_oxxo")] MexOxxo,
	    [StringValue("mx_otherbank_tc")] MexOtherBankCreditCard,
	    [StringValue("mx_ixe_tc")] MexIxeCreditCard,
	    [StringValue("mx_ixe_tb")] MexIxeBankTransfer,
	    [StringValue("mx_ixe_dr")] MexIxeReferenceDeposit,
	    [StringValue("mx_hsbc_td")] MexHsbcDebitCard,
	    [StringValue("mx_hsbc_tb")] MexHsbcBankTransfer,
	    [StringValue("mx_dm")] MexDineroMailFunds,
	    [StringValue("mx_banorte_td")] MexBanorteDebitCard,
	    [StringValue("mx_bancomer_tc")] MexBancomerCreditCard,
	    [StringValue("mx_bancomer_tb")] MexBancomerBankTransfer,
	    [StringValue("mx_bancomer_dr")] MexBancomerReferenceDeposit,
	    [StringValue("mx_banamex_td")] MexBanamexDebitCard,
	    [StringValue("mx_amex")] MexAmex,
	    [StringValue("mx_7eleven")] Mex7Eleven,
    }
}
