﻿namespace DineroMailWindowsPhoneSDK
{
    using System.Collections.Generic;

    public class Payment
    {
        public string Merchant { get; set; }
        public Country Country { get; set; }
        public string SellerName { get; set; }
        public Language Language { get; set; }
        public long TransactionId { get; set; }
        public Currency Currency { get; set; }
        public string OkUrl { get; set; }
        public string ErrorUrl { get; set; }
        public string PendingUrl { get; set; }       
        public PaymentMethod DefaultPaymentMethod { get; set; }
        public bool BuyerCanAddMessage { get; set; }
        public bool BuyerCanChangeQuantity { get; set; }
        public bool DisplayShipping { get; set; }
        public bool DisplayAdditionalCharge { get; set; }
        public float AdditionalFixedCharge { get; set; }
        public Currency AdditionalFixedChargeCurrency { get; set; }
        public float AdditionalVariableCharge { get; set; }
        public bool ExpandedStepPaymentMethods { get; set; }
        public bool ExpandedStepAdditionalData { get; set; }
        public bool ExpandedStepShipping { get; set; }
        public bool ExpandedSaleDetail { get; set; }
        public bool SummaryVisible { get; set; }

        public Buyer Buyer { get; set; }

        internal List<Product> Products
        {
            get
            {
                return this.products ?? (this.products = new List<Product>());
            }
        }

        internal List<AdditionalVar> AdditionalVars
        {
            get
            {
                return this.additionalVars ?? (this.additionalVars = new List<AdditionalVar>());
            }
        }

        internal List<AvailablePaymentMethod> AvailablePaymentMethods
        {
            get
            {
                if (this.availablePaymentMethods == null)
                {
                    availablePaymentMethods = new List<AvailablePaymentMethod>();    
                }

                return this.availablePaymentMethods;
            }
        }

        private List<Product> products; 

        private List<AvailablePaymentMethod> availablePaymentMethods;

        private List<AdditionalVar> additionalVars; 

        public void AddProduct(Product product)
        {
            this.Products.Add(product);
        }

        public void AddAvailablePaymentMethod(PaymentMethod availablePaymentMethod)
        {
            this.AvailablePaymentMethods.Add(new AvailablePaymentMethod { PaymentMethod = availablePaymentMethod });
        }

        public void AddAvailablePaymentMethod(PaymentMethod availablePaymentMethod, List<int> availableInstalments)
        {
            this.AvailablePaymentMethods.Add(new AvailablePaymentMethod { AvailableInstalments = availableInstalments, PaymentMethod = availablePaymentMethod });
        }

        public void AddAdditionalVar(AdditionalVar additionalVar)
        {
            this.AdditionalVars.Add(additionalVar);
        }
    }
}
