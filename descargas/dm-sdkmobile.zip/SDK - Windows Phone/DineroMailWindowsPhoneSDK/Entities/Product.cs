﻿namespace DineroMailWindowsPhoneSDK
{
    public class Product 
    {
	    public string Name { get; set; }
	    public string Code { get; set; }
	    public int Quantity { get; set; }
	    public float Amount { get; set; }
	    public Currency Currency { get; set; }
	    public Weight Weight { get; set; }
	    public float WeightValue { get; set; }
	    public float ShippingCostDefault { get; set; }
	    public float ShippingCostTwo { get; set; }
	    public ShippingType ShippingType { get; set; }
	    public Currency ShippingCurrency { get; set; }
    }
}
