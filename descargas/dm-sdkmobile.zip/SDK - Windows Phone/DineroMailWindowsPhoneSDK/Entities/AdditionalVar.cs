﻿using System;

namespace DineroMailWindowsPhoneSDK
{
    public class AdditionalVar
    {
        public string Description { get; set; }
	    public string Value { get; set; }
	    public bool IsVisible { get; set; }
	    public bool IsRequired { get; set; }
    }
}
