﻿namespace DineroMailWindowsPhoneSDK
{
    using System.Collections.Generic;

    public class AvailablePaymentMethod
    {
        public PaymentMethod PaymentMethod { get; set; }

        public List<int> AvailableInstalments { get; set; }
    }
}
