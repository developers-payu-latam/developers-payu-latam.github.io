﻿namespace WP7SamplePaymentApp
{
    using System;
    using DineroMailWindowsPhoneSDK;
    using Microsoft.Phone.Controls;

    public partial class CheckOut : PhoneApplicationPage
    {
        public CheckOut()
        {
            InitializeComponent();

            var payment = this.CreatePayment();

            DineroMailCheckOut.ProceedToCheckOut(payment);
        }

        private Payment CreatePayment()
        {
            var payment = new Payment
                {
                    Merchant = "adrian.eidelman@gmail.com",
                    Currency = Currency.Ars,
                    Language = DineroMailWindowsPhoneSDK.Language.Spanish,
                    Country = Country.Argentina
                };

            payment.AddAvailablePaymentMethod(PaymentMethod.All);
            payment.AddProduct(new Product { Amount = 39.99F, Quantity = 1, Name = "Pen Drive 4gb"});

            return payment;
        }

        private void DineroMailCheckOut_CheckOutProcessFinished(object sender, EventArgs e)
        {
            OperationStatus status = DineroMailCheckOut.OperationStatus;

            //-- do something
        }

        protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
        }
    }
}