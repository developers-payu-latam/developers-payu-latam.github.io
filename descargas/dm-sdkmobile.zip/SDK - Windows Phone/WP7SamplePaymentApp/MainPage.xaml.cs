﻿namespace WP7SamplePaymentApp
{
    using System;
    using System.Windows;
    using Microsoft.Phone.Controls;

    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        private void Pay_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/CheckOutPage.xaml", UriKind.Relative));
        }
    }
}