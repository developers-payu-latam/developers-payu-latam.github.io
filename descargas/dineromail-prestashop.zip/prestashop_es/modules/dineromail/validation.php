<?php

include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../header.php');
include(dirname(__FILE__).'/dineromail.php');

	$currency = new Currency
	(intval(isset($_POST['currency_payement']) ? $_POST['currency_payement'] : $cookie->id_currency));
	
	$total = floatval(number_format($cart->getOrderTotal(true, 3), 2, '.', ''));

	$dineromail = new dineromail();

	$mailVars = array
	(
		'{bankwire_owner}' 		=> $dineromail->textshowemail, 
		'{bankwire_details}' 	=> '', 
		'{bankwire_address}' 	=> ''
	);
	
	$dineromail->validateOrder
	(
		$cart->id, 
		Configuration::get('dineromail_STATUS_3'), 
		$total, 
		$dineromail->displayName, 
		NULL, 
		$mailVars, 
		$currency->id
	);
	
	$order 		= new Order($dineromail->currentOrder);
	$idCustomer = $order->id_customer;
	$idLang		= $order->id_lang;
	$customer 	= new Customer(intval($idCustomer));
	$CusMail	= $customer->email;
		
	$mailVars 	= array
	(
		'{email}'			=> Configuration::get('PS_SHOP_EMAIL'),
		'{firstname}' 		=> stripslashes($customer->firstname), 
		'{lastname}' 		=> stripslashes($customer->lastname	),
		'{terceiro}'		=> stripslashes($dineromail->displayName),
		'{id_order}'		=> stripslashes($dineromail->currentOrder),
		'{status}'			=> stripslashes($dineromail->getStatus(Configuration::get('dineromail_STATUS_3'))),
		'{link}'			=> $dineromail->getUrlByMyOrder($order)
	);
	

	Tools::redirectLink(__PS_BASE_URI__.'order-confirmation.php?id_cart='.$cart->id.'&id_module='.$dineromail->id.'&id_order='.$dineromail->currentOrder.'&key='.$order->secure_key);

?>