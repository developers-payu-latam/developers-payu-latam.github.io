<?php
ini_set("allow_url_fopen", 1); 
ini_set("allow_url_include", 1);

/* SSL Management */
$useSSL = true;

include(dirname(__FILE__).'\..\..\config\config.inc.php');
include(dirname(__FILE__).'\dineromail.php');

$dineromail = new dineromail();

$notificacion = $_REQUEST['Notificacion'];	

$notificacion = str_replace("<?xmlversion='1.0'encoding='ISO-8859-1'?>", "", $notificacion);
$doc = new SimpleXMLElement($notificacion);		

foreach ($doc ->operaciones ->operacion  as  $operacion) {
	$id_operacion= $operacion->id;  
	$dineromail->consultaIpn($id_operacion);
}
?>