<?php
class dineromail extends PaymentModule
{
	private $_html 			= '';
    private $_postErrors 	= array();
    public $currencies;
	
	public function __construct()
    {
        $this->name 			= 'dineromail';
        $this->tab 				= 'payments_gateways';
        $this->version 			= '1.4.6.2';

        $this->currencies 		= true;
        $this->currencies_mode 	= 'radio';

        parent::__construct();

        $this->page 			= basename(__file__, '.php');
        $this->displayName 		= $this->l('DineroMail');
        $this->description 		= $this->l('Aceptar pagos a través de DineroMail');
		$this->confirmUninstall = $this->l('¿Está seguro que desea eliminar sus datos?');
		$this->textshowemail 	= $this->l('Usted debe seguir atentamente los procedimentos de pago de DineroMail, para que su compra sea validada.');
	}
	
	public function install()
	{
		
		if ( !Configuration::get('dineromail_STATUS_1') )
			$this->create_states();
		if 
		(
			!parent::install() 
		OR 	!Configuration::updateValue('dineromail_BUSINESS', 'example@example.com')
		OR 	!Configuration::updateValue('dineromail_CUENTA', 	  '1234567')
		OR 	!Configuration::updateValue('dineromail_COUNTRY', 	  '1')
		OR 	!Configuration::updateValue('dineromail_IPNPASS', 	  'ipnpass') 
		OR 	!$this->registerHook('payment') 
		OR 	!$this->registerHook('paymentReturn')
		OR 	!$this->registerHook('home')
		)
			return false;
			
		return true;
	}

		public function create_states()
	{
		
		$this->order_state = array(
		array( '49E857', '11110', 'DineroMail - Completo', 'payment' ),
		array( 'F6FF0D', '00100', 'DineroMail - Pendente', '' ),
		array( 'E8350C', '11110', 'DineroMail - Cancelado', 'order_canceled' ),
		array( 'F6FF0D', '00100', 'DineroMail - Em Aberto', '' )
		);
		
		
		$languages = Db::getInstance()->ExecuteS('
		SELECT `id_lang`, `iso_code`
		FROM `'._DB_PREFIX_.'lang`
		');
				
		foreach ($this->order_state as $key => $value)
		{
			
			Db::getInstance()->Execute
			('
				INSERT INTO `' . _DB_PREFIX_ . 'order_state` 
			( `invoice`, `send_email`, `color`, `unremovable`, `logable`, `delivery`) 
				VALUES
			('.$value[1][0].', '.$value[1][1].', \'#'.$value[0].'\', '.$value[1][2].', '.$value[1][3].', '.$value[1][4].');
			');
			
			
			$this->figura 	= mysql_insert_id();
			
			foreach ( $languages as $language_atual )
			{
				
				Db::getInstance()->Execute
				('
					INSERT INTO `' . _DB_PREFIX_ . 'order_state_lang` 
				(`id_order_state`, `id_lang`, `name`, `template`)
					VALUES
				('.$this->figura .', '.$language_atual['id_lang'].', \''.$value[2].'\', \''.$value[3].'\');
				');
					
			}
			
			
				
				$file 		= (dirname(__file__) . "/icons/$key.gif");
				$newfile 	= (dirname( dirname (dirname(__file__) ) ) . "/img/os/$this->figura.gif");
				if (!copy($file, $newfile)) {
    			return false;
    			}
    			
    		Configuration::updateValue("dineromail_STATUS_$key", 	$this->figura);
    		   				
		}
		
		return true;
		
	}

	public function uninstall()
	{
		if 
		(
			!Configuration::deleteByName('dineromail_BUSINESS')
		OR	!Configuration::deleteByName('dineromail_CUENTA')
		OR	!Configuration::deleteByName('dineromail_COUNTRY')
		OR	!Configuration::deleteByName('dineromail_IPNPASS')
		OR	!Configuration::deleteByName('dineromail_LOGO')
		OR 	!parent::uninstall()
		) 
			return false;
		
		return true;
	}

	public function getContent()
	{
		$this->_html = '<h2>DineroMail</h2>';
		if (isset($_POST['submitdineromail']))
		{
			if (empty($_POST['business'])) $this->_postErrors[] = $this->l('Escriba un correo eletrónico válido');
			elseif (empty($_POST['dm_cuenta'])) $this->_postErrors[] = $this->l('Escriba el número de su cuenta registrada en DineroMail');
			elseif (!Validate::isEmail($_POST['business'])) $this->_postErrors[] = $this->l('Escriba un correo eletrónico válido');
			
				if (!sizeof($this->_postErrors)) {
					Configuration::updateValue('dineromail_BUSINESS', $_POST['business']);
					if (!empty($_POST['dm_cuenta']))
					{
					Configuration::updateValue('dineromail_CUENTA', $_POST['dm_cuenta']);
					}
					if (!empty($_POST['country']))
					{
					Configuration::updateValue('dineromail_COUNTRY', $_POST['country']);
					}
					if (!empty($_POST['ipnpass']))
					{
					Configuration::updateValue('dineromail_IPNPASS', $_POST['ipnpass']);
					}
					if (!empty($_POST['logo']))
					{
					Configuration::updateValue('dineromail_LOGO', $_POST['logo']);
					}
				    $this->displayConf();
				}
				else $this->displayErrors();
		}

		$this->displaydineromail();
		$this->displayFormSettingsdineromail();
		return $this->_html;
	}
	
	public function displayConf()
	{
		$this->_html .= '
		<div class="conf confirm">
			<img src="../img/admin/ok.gif" alt="'.$this->l('Confirmation').'" />
			'.$this->l('Configuraciones actualizadas').'
		</div>';
	}
	
	public function displayErrors()
	{
		$nbErrors = sizeof($this->_postErrors);
		$this->_html .= '
		<div class="alert error">
			<h3>'.($nbErrors > 1 ? $this->l('There are') : $this->l('There is')).' '.$nbErrors.' '.($nbErrors > 1 ? $this->l('errors') : $this->l('error')).'</h3>
			<ol>';
		foreach ($this->_postErrors AS $error)
			$this->_html .= '<li>'.$error.'</li>';
		$this->_html .= '
			</ol>
		</div>';
	}

	public function displaydineromail()
	{
		$this->_html .= '
		<img src="../modules/dineromail/imagens/ba_argentina.gif" style="float:left; margin-right:15px;" />
		<img src="../modules/dineromail/imagens/ba_brasil.gif" style="float:left; margin-right:15px;" />
		<img src="../modules/dineromail/imagens/ba_chile.gif" style="float:left; margin-right:15px;" />
		<img src="../modules/dineromail/imagens/ba_mexico.gif" style="float:left; margin-right:15px;" /><br /><br /><br /><br /><br /><br />
		<b>'.$this->l('Este módulo le permite aceptar pagos a través de DineroMail.').'</b><br /><br />
		'.$this->l('Introduzca sus datos solickitados abajo para usar DienroMail como soilución de pago.').'<br />		
		<br /><br /><br />';
	}

	public function displayFormSettingsdineromail()
	{
		$conf 			= Configuration::getMultiple
		(array(
			'dineromail_BUSINESS',
			'dineromail_CUENTA',
			'dineromail_COUNTRY',
			'dineromail_IPNPASS',
			'dineromail_LOGO'
			  )
		);
		
		$businessDM 	= array_key_exists('business', $_POST) ? $_POST['business'] : (array_key_exists('dineromail_BUSINESS', $conf) ? $conf['dineromail_BUSINESS'] : '');
		$cuenta 		= array_key_exists('dm_cuenta', $_POST) ? $_POST['dm_cuenta'] : (array_key_exists('dineromail_CUENTA', $conf) ? $conf['dineromail_CUENTA'] : '');
		$country 		= array_key_exists('country', $_POST) ? $_POST['country'] : (array_key_exists('dineromail_COUNTRY', $conf) ? $conf['dineromail_COUNTRY'] : '');
		$ipnpass 		= array_key_exists('ipnpass', $_POST) ? $_POST['ipnpass'] : (array_key_exists('dineromail_IPNPASS', $conf) ? $conf['dineromail_IPNPASS'] : '');
		$logo 		    = array_key_exists('logo', $_POST) ? $_POST['logo'] : (array_key_exists('dineromail_LOGO', $conf) ? $conf['dineromail_LOGO'] : '');
		
		$checked="";
		$checked1="";
		$checked2="";
		$checked3="";
		if($country==1){
			$checked="checked='checked'";
		}
		
		if($country==2){
			$checked1="checked='checked'";
		}
		
		if($country==3){
			$checked2="checked='checked'";
		}

		if($country==4){
			$checked3="checked='checked'";
		}		
		
		$this->_html .= '
		<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
		<fieldset>
			<legend><img src="../img/admin/contact.gif" />'.$this->l('Configuraciones').'</legend>
			<label>'.$this->l('Correo eletrónico registrado en DineroMail').':</label>
			<div class="margin-form"><input type="text" size="33" name="business" value="'.htmlentities($businessDM, ENT_COMPAT, 'UTF-8').'" /></div>
			<br />
			
			<label>'.$this->l('Número de Cuenta de DineroMail').':</label>
			<div class="margin-form"><input type="text" size="33" name="dm_cuenta" value="'.$cuenta.'" /></div>
			<br />
			
			<label>'.$this->l('País que va utilizar DineroMail').':</label>
			<div class="margin-form">
				 <input type=radio id="country1" name="country" value="1"'.$checked.'  >&nbsp;-&nbsp;'.$this->l('Argentina').'<br>
		         <input type=radio id="country2" name="country" value="2"'.$checked1.' >&nbsp;-&nbsp;'.$this->l('Brasil').'<br>
		         <input type=radio id="country3" name="country" value="3"'.$checked2.' >&nbsp;-&nbsp;'.$this->l('Chile').'<br>
		         <input type=radio id="country4" name="country" value="4"'.$checked3.' >&nbsp;-&nbsp;'.$this->l('México').'<br>
		    </div>     
			<br />
			
			<label>'.$this->l('Contraseña IPN').':</label>
			<div class="margin-form"><input type="text" size="33" name="ipnpass" value="'.$ipnpass.'" /></div>
			<br />
			
			<label>'.$this->l('Logo da Tienda').':</label>
			<div class="margin-form"><input type="text" size="33" name="logo" value="'.$logo.'" /></div>
			<br />
			
			<center><input type="submit" name="submitdineromail" value="'.$this->l('Atualizar').'" class="button" /></center>
		</fieldset>
		</form>';
		
		
	}

    public function execPayment($cart)
    {
        global $cookie, $smarty;
        $invoiceAddress 	= new Address(intval($cart->id_address_invoice));
        $customerPag 		= new Customer(intval($cart->id_customer));
        $currencies 		= Currency::getCurrencies();
        $currencies_used 	= array();
		$currency 			= $this->getCurrency();

        $currencies 		= Currency::getCurrencies();
        
		$country=Configuration::get('dineromail_COUNTRY');
		if($country==1){
			$img="banner_ar.gif";
		}
		elseif($country==2){
			$img="banner_br.jpg";
		}
		elseif($country==3){
			$img="banner_ch.gif";
		}
		elseif($country==4){
			$img="banner_mx.gif";
		}
		
		
        foreach ($currencies as $key => $currency)
            $smarty->assign(array(
			'currency_default' => new Currency(Configuration::get('PS_CURRENCY_DEFAULT')),
            'currencies' => $currencies_used, 
			'imgBtn' => "modules/dineromail/imagens/".$img,
			'imgBtn2' => "modules/dineromail/imagens/".$img,
            'currency_default' => new Currency(Configuration::get('PS_CURRENCY_DEFAULT')),
            'currencies' => $currencies_used, 
			'total' => number_format(Tools::convertPrice($cart->getOrderTotal(true, 3), $currency), 2, '.', ''), 
			'this_path_ssl' => (Configuration::get('PS_SSL_ENABLED') ?
            'https://' : 'http://') . htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT,'UTF-8') . __PS_BASE_URI__ . 'modules/' . $this->name . '/'));

        return $this->display(__file__, 'payment_execution.tpl');
    }
	
	public function hookPayment($params)
	{
		
		global $smarty;
		
		$country=Configuration::get('dineromail_COUNTRY');
		if($country==1){
			$img="pagar-medios_ar.gif";
			$imgbn="banner_ar.gif";
		}
		elseif($country==2){
			$img="pagar-medios_br.gif";
			$imgbn="banner_br.jpg";
		}
		elseif($country==3){
			$img="pagar-medios_ch.gif";
			$imgbn="banner_ch.gif";
		}
		elseif($country==4){
			$img="pagar-medios_mx.gif";
			$imgbn="banner_mx.gif";
		}
		
		$smarty->assign(array(
			'imgBtn' => "modules/dineromail/imagens/".$img,
			'imgBtn2' => "modules/pagseguro/imagens/".$img,
			'imgBnr' => "modules/pagseguro/imagens/".$imgbn,
			'this_path' => $this->_path, 'this_path_ssl' => (Configuration::get('PS_SSL_ENABLED') ?
			'https://' : 'http://') . htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT,
			'UTF-8') . __PS_BASE_URI__ . 'modules/' . $this->name . '/'));
		return $this->display(__file__, 'payment.tpl');
		
	}
	
	public function hookPaymentReturn($params)
    {
        global $smarty, $cookie;
		$address = new Address(intval($params['cart']->id_address_invoice));
		$state 				= $params['objOrder']->getCurrentState();  
        $order 				= new Order($dineromail->currentOrder);
		$DadosOrder 		= new Order($params['objOrder']->id);
		$DadosCart 			= new Cart($DadosOrder->id_cart);
		$ArrayListaProdutos = $DadosOrder->getProducts();
		$discounts = $DadosCart->getDiscounts(); 
		$merchant=Configuration::get('dineromail_CUENTA');
		$country=Configuration::get('dineromail_COUNTRY');
		$logo=Configuration::get('dineromail_LOGO');
		
		if($country==1){
			$currency="ars";
			$language="es";
		}
		elseif($country==2){
			$currency="brl";
			$language="pt";
		}
		elseif($country==3){
			$currency="clp";
			$language="es";
		}
		elseif($country==4){
			$currency="mxn";
			$language="es";
		}
		
		$formdineromail  ="<form accept-charset='ISO-8859-1' action='https://checkout.dineromail.com/CheckOut' method='post'>";		
		$formdineromail .="<input type='hidden' name='tool' value='button' /> ";
		$formdineromail .="<input type='hidden' name='change_quantity' value='0' /> ";
		$formdineromail .="<input type='hidden' name='merchant' value='".$merchant."' /> ";
		$formdineromail .="<input type='hidden' name='country_id' value='".$country."' /> ";
		$formdineromail .="<input type='hidden' name='header_image' value='".$logo."' /> ";
		$formdineromail .="<input type='hidden' name='seller_name' value='".$smarty->getVariable('shop_name')."' /> ";
		$formdineromail .="<input type='hidden' name='language' value='".$language."' /> ";
		$formdineromail .="<input type='hidden' name='transaction_id' value='".$params['objOrder']->id."' /> ";
		$formdineromail .="<input type='hidden' name='currency' value='".$currency."' /> ";
		$formdineromail .="<input type='hidden' name='ok_url' value='".$smarty->getVariable('base_dir')."modules/dineromail/payment_confirm.php?transaction=".$params['objOrder']->id."&status=ok' /> ";
		$formdineromail .="<input type='hidden' name='pending_url' value='".$smarty->getVariable('base_dir')."modules/dineromail/payment_confirm.php?transaction=".$params['objOrder']->id."&status=ok' /> ";
		$formdineromail .="<input type='hidden' name='error_url' value='".$smarty->getVariable('base_dir')."modules/dineromail/payment_confirm.php?transaction=".$params['objOrder']->id."&status=' /> ";
		$formdineromail .="<input type='hidden' name='buyer_name' value='".$address->firstname."' /> ";
		$formdineromail .="<input type='hidden' name='buyer_lastname' value='".$address->lastname."' /> ";
		$formdineromail .="<input type='hidden' name='buyer_email' value='".$cookie->email."' /> ";
		$formdineromail .="<input type='hidden' name='buyer_phone' value='".$address->phone."' /> ";
		
		$discount=0;
		if($discounts){
			foreach ($discounts as $desconto)
			{
				$discount=$discount+$desconto["value_real"];
				
			}
			$formdineromail .="<input type='hidden' name='display_additional_charge' value='1' /> ";
			$formdineromail .="<input type='hidden' name='additional_fixed_charge' value='".sprintf('%.1f',$discount)."-' /> ";
			$formdineromail .="<input type='hidden' name='additional_fixed_charge_currency' value='".$currency."' /> ";
		}
		
		$i = 1;
		$trximp=0;
		foreach ($ArrayListaProdutos as $product)
		{
			$formdineromail .="<input type='hidden' name='item_name_".$i."' value='".$product["product_name"]."' /> ";
			$formdineromail .="<input type='hidden' name='item_code_".$i."' value='".$product["product_id"]."' /> ";
			$formdineromail .="<input type='hidden' name='item_quantity_".$i."' value='".$product["product_quantity"]."' /> ";
			$formdineromail .="<input type='hidden' name='item_ammount_".$i."' value='".sprintf('%.2f',$product["product_price"])."' /> ";
			$formdineromail .="<input type='hidden' name='item_currency_".$i."' value='".$currency."' /> ";
			$priceproduct=sprintf('%.2f',$product["product_price"]);
			$pricetax=sprintf('%.2f',$product["product_price_wt"]);
			$trximp=$trximp+(($pricetax-$priceproduct)*$product["product_quantity"]);
			$i++;
		}
		
		$formdineromail .="<input type='hidden' name='item_name_".$i."' value='Tasa de Servicio' /> ";
		$formdineromail .="<input type='hidden' name='item_code_".$i."' value='#FRT' /> ";
		$formdineromail .="<input type='hidden' name='item_quantity_".$i."' value='1' /> ";
		$formdineromail .="<input type='hidden' name='item_ammount_".$i."' value='".sprintf('%.2f',$DadosOrder->total_shipping)."' /> ";
		$formdineromail .="<input type='hidden' name='item_currency_".$i."' value='".$currency."' /> ";
		
		$counttax=$i+1;
		
		$formdineromail .="<input type='hidden' name='item_name_".$counttax."' value='Tasa de Impuestos' /> ";
		$formdineromail .="<input type='hidden' name='item_code_".$counttax."' value='#IPT' /> ";
		$formdineromail .="<input type='hidden' name='item_quantity_".$counttax."' value='1' /> ";
		$formdineromail .="<input type='hidden' name='item_ammount_".$counttax."' value='".$trximp."' /> ";
		$formdineromail .="<input type='hidden' name='item_currency_".$counttax."' value='".$currency."' /> ";
		
		$formdineromail .="<input type='submit' value='Efetuar Pagamento' class='exclusive_large' />";
		$formdineromail .="</form>";
		
		$smarty->assign(array(
			'totalApagar' 	=> Tools::displayPrice($params['total_to_pay'],$params['currencyObj'], false, false), 
			'status' 		=> 'ok', 
			'id_order' 		=> $params['objOrder']->id,
			'secure_key' 	=> $params['objOrder']->secure_key,
			'id_module' 	=> $this->id,
			'formdineromail' => $formdineromail
		));
		
		return $this->display(__file__, 'payment_return.tpl');
    }
    
        function hookHome($params)
	{
    	include(dirname(__FILE__).'/includes/retorno.php');
    }
    
        function getStatus($param)
    {
    	global $cookie;
    		
    		$sql_status = Db::getInstance()->Execute
		('
			SELECT `name`
			FROM `'._DB_PREFIX_.'order_state_lang`
			WHERE `id_order_state` = '.$param.'
			AND `id_lang` = '.$cookie->id_lang.'
			
		');
		
		return mysql_result($sql_status, 0);
    }


	public function getUrlByMyOrder($myOrder)
	{

		$module				= Module::getInstanceByName($myOrder->module);			
		$pagina_qstring		= __PS_BASE_URI__."order-confirmation.php?id_cart="
							  .$myOrder->id_cart."&id_module=".$module->id."&id_order="
							  .$myOrder->id."&key=".$myOrder->secure_key;			
		
		if	(	$_SERVER['HTTPS']	!=	"on"	)
		$protocolo			=	"http";
		
		else
		$protocolo			=	"https";
		
		$retorno 			= $protocolo . "://" . $_SERVER['SERVER_NAME'] . $pagina_qstring;			
		return $retorno;

	}
	
	public function okPayment($status,$id)
    {
    	 
		if($status=="ok"){
			$id_order_state = Db::getInstance()->getValue('
			SELECT `id_order_history`
			FROM `'._DB_PREFIX_.'order_history`
			WHERE `id_order` = '.(int)($id).' AND `id_order_state` = '.(int)(Configuration::get('dineromail_STATUS_1')).'
			ORDER BY `date_add` DESC, `id_order_history` DESC');
			
			if(!$id_order_state){
				$orderHistory = new OrderHistory();
				$orderHistory->id_order = (int)($id);
				$orderHistory->changeIdOrderState((int)(Configuration::get('dineromail_STATUS_1')), (int)($id));
				$orderHistory->addWithemail();
			}			
        	return $this->display(__file__, 'payment_confirm.tpl');					
			
		}	
		else{
			$id_order_state = Db::getInstance()->getValue('
			SELECT `id_order_history`
			FROM `'._DB_PREFIX_.'order_history`
			WHERE `id_order` = '.(int)($id).' AND `id_order_state` = '.(int)(Configuration::get('dineromail_STATUS_2')).' 
			ORDER BY `date_add` DESC, `id_order_history` DESC');
			
			if(!$id_order_state){
				$orderHistory = new OrderHistory();
				$orderHistory->id_order = (int)($id);
				$orderHistory->changeIdOrderState((int)(Configuration::get('dineromail_STATUS_2')), (int)($id));
				$orderHistory->addWithemail();
			}			
			return $this->display(__file__, 'payment_nconfirm.tpl');
		}
		
    }
    
	public function consultaIpn($id_operacion)
	{
		global $smarty, $cookie;
		
		$email=Configuration::get('dineromail_BUSINESS');
		$nrocta=Configuration::get('dineromail_CUENTA');
		$senhaipn=Configuration::get('dineromail_IPNPASS');
		$country=Configuration::get('dineromail_COUNTRY');
		if($country==1){
			$url="https://argentina.dineromail.com/Vender/Consulta_IPN.asp";			
		}
		elseif($country==2){
			$url="https://brasil.dineromail.com/Vender/Consulta_IPN.asp";
		}
		elseif($country==3){
			$url="https://chile.dineromail.com/Vender/Consulta_IPN.asp";
		}
		elseif($country==4){
			$url="https://mexico.dineromail.com/Vender/Consulta_IPN.asp";
		}	
		
		
		$data = 'DATA=<REPORTE><NROCTA>'.$nrocta.'</NROCTA><DETALLE><CONSULTA><CLAVE>'.$senhaipn.'</CLAVE><TIPO>1</TIPO><OPERACIONES><ID>'.$id_operacion.'</ID></OPERACIONES></CONSULTA></DETALLE></REPORTE>';

		$url = parse_url($url);

		$host = $url['host'];

		$path = $url['path'];		

		$fp = fsockopen($host, 80);		

		fputs($fp, "POST $path HTTP/1.1\r\n");

		fputs($fp, "Host: $host\r\n");

		//fputs($fp, "Referer: $referer\r\n");

		fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n");

		fputs($fp, "Content-length: ". strlen($data) ."\r\n");

		fputs($fp, "Connection: close\r\n\r\n");

		fputs($fp, $data);

		$result = ''; 

		while(!feof($fp)) {
			// resultado del request
			$result .= fgets($fp, 128);
		}
		
		// cierra conexion
		fclose($fp);

		// separa el header del content
		$result = explode("\r\n\r\n", $result, 2);

		//$header = isset($result[0]) ? $result[0] : '';
		
		$content = isset($result[1]) ? $result[1] : '';	

		$xml = new SimpleXMLElement($content);

		$estadoxml = $xml ->ESTADOREPORTE;
		
		if($estadoxml==1){
			
			foreach ($xml ->DETALLE->OPERACIONES->OPERACION  as  $OPERACION) {
				$trx_id      = $OPERACION->ID;  
				$estadotrans = $OPERACION->ESTADO; 
				$data        = $OPERACION->FECHA; 
				
				$id_order_state = Db::getInstance()->getValue('
				SELECT `id_order_history`
				FROM `'._DB_PREFIX_.'order_history`
				WHERE `id_order` = '.(int)($trx_id).' AND `id_order_state` = '.(int)(Configuration::get('dineromail_STATUS_0')).' 
				ORDER BY `date_add` DESC, `id_order_history` DESC');
				
				
				
				$verify=2;
				$verify_quantity=0;
				foreach ($OPERACION->ITEMS->ITEM  as  $ITEM) {
					$verify_quantity++;					
					
					$description = $ITEM->DESCRIPCION;
					$value_unit  = $ITEM->PRECIOUNITARIO;
					$quantit     = $ITEM->CANTIDAD;
					
					
					
					$items = Db::getInstance()->ExecuteS("SELECT * FROM "._DB_PREFIX_."order_detail WHERE id_order = ".(int)($trx_id)." AND product_name= '".$description."' AND product_quantity = '".(int)($quantit)."' AND REPLACE(FORMAT(product_price,2),',','') = '".$value_unit."' ");
					
					if ($items){
						foreach ($items AS $item)
							$verify++;
					}
							
				}
				
				if($verify==$verify_quantity){
					if($estadotrans==2){
						$orderHistory = new OrderHistory();
						$orderHistory->id_order = (int)($trx_id);
						$orderHistory->changeIdOrderState((int)(Configuration::get('dineromail_STATUS_0')), (int)($trx_id));
						$orderHistory->addWithemail();		 			     	
					}
					elseif($estadotrans==1){
						if(!$id_order_state){
							$orderHistory = new OrderHistory();
							$orderHistory->id_order = (int)($trx_id);
							$orderHistory->changeIdOrderState((int)(Configuration::get('dineromail_STATUS_1')), (int)($trx_id));
							$orderHistory->addWithemail();
						}						 					
										
					}
					elseif($estadotrans==3){
						if(!$id_order_state){
							$orderHistory = new OrderHistory();
							$orderHistory->id_order = (int)($trx_id);
							$orderHistory->changeIdOrderState((int)(Configuration::get('dineromail_STATUS_2')), (int)($trx_id));
							$orderHistory->addWithemail();
						}					
					}	
				}	
				else{
					 
					 $id_lang = Db::getInstance()->getValue('SELECT `id_lang` FROM `'._DB_PREFIX_.'orders` WHERE `id_order` = '.(int)($trx_id));       
					 $body='Puede tener ocurr un intento de fraude en el transación de número'.$trx_id.'. Porque el valor de producto en la Tienda no és lo mismo pago en DineroMail.';
					 Mail::Send((int)($id_lang), '', 'Posible Intento de Fraude', date("d/m/Y"), $email,'','','','','',$body);					 
				
				}	
			}
		}
		
	}
	    
}
?>