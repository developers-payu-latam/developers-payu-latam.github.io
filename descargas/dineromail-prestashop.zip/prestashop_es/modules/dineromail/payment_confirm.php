<?php
global $smarty, $cookie;
/* SSL Management */
$useSSL = true;

include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../header.php');
include(dirname(__FILE__).'/dineromail.php');

if (!$cookie->isLogged())
    Tools::redirect('authentication.php?back=order.php');
$dineromail = new dineromail();

echo $dineromail->okPayment($_REQUEST["status"],$_REQUEST["transaction"]);

include_once(dirname(__FILE__).'/../../footer.php');
//sleep(10);
//Tools::redirect('');
?>