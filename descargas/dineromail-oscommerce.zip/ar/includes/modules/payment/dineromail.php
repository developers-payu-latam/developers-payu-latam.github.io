<?php
/*
$Id: dineromail.php,v 0.05 2008/04/12 15:20:15 fajs Exp $

osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com

Copyright (c) 2003 osCommerce

Released under the GNU General Public License
*/

class dineromail {
var $code, $title, $description, $enabled;


function dineromail() {
global $order;

$this->code = 'dineromail';
$this->title = MODULE_PAYMENT_DINEROMAIL_TEXT_TITLE;
$this->description = MODULE_PAYMENT_DINEROMAIL_TEXT_DESCRIPTION;
$this->sort_order = MODULE_PAYMENT_DINEROMAIL_SORT_ORDER;
$this->enabled = ((MODULE_PAYMENT_DINEROMAIL_STATUS == 'True') ? true : false);

if ((int)MODULE_PAYMENT_DINEROMAIL_ORDER_STATUS_ID > 0) {
$this->order_status = MODULE_PAYMENT_DINEROMAIL_ORDER_STATUS_ID;
}

if (is_object($order)) $this->update_status();

$this->form_action_url = 'https://www.dineromail.com/Shop/Shop_Ingreso.asp';
}

function update_status() {
global $order;

if ( ($this->enabled == true) && ((int)MODULE_PAYMENT_DINEROMAIL_ZONE > 0) ) {
$check_flag = false;
$check_query = tep_db_query("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_DINEROMAIL_ZONE . "' and zone_country_id = '" . $order->billing['country']['id'] . "' order by zone_id");
while ($check = tep_db_fetch_array($check_query)) {
if ($check['zone_id'] < 1) {
$check_flag = true;
break;
} elseif ($check['zone_id'] == $order->billing['zone_id']) {
$check_flag = true;
break;
}
}

if ($check_flag == false) {
$this->enabled = false;
}
}
}

function javascript_validation() {
return false;
}

function selection() {
return array('id' => $this->code,
'module' => $this->title);
}

function pre_confirmation_check() {
return false;
}

function confirmation() {
return false;
}

function process_button() {
global $order, $currencies, $currency;

$my_currency = $currency;

$a = $order->info['total'];
$b = $order->info['shipping_cost'];
$c = $currencies->get_value($my_currency);
$d = $currencies->get_decimal_places($my_currency);
$total = $a * $c;
$precio = number_format($total, $d, '.', '');

$productos = "Compra en " . STORE_NAME . ": ";

for ($i=0, $n=sizeof($order->products); $i<$n; $i++) {
    $productos .= "// " .  $order->products[$i]['qty'] . '&nbsp;x ' . $order->products[$i]['name'];
    }
if ($my_currency == 'USD'){ 
	$TipoMoneda = '2';}else{
	$TipoMoneda = '1';}


$process_button_string = tep_draw_hidden_field('NombreItem', $productos) .
tep_draw_hidden_field('TipoMoneda', $TipoMoneda) .
tep_draw_hidden_field('PrecioItem', $precio) .
tep_draw_hidden_field('usr_nombre', $order->customer['firstname']) .
tep_draw_hidden_field('usr_apellido', $order->customer['lastname']) .
tep_draw_hidden_field('usr_tel_numero', $order->customer['telephone']) .
tep_draw_hidden_field('usr_email', $order->customer['email_address']) .
tep_draw_hidden_field('E_Comercio', MODULE_PAYMENT_DINEROMAIL_ID) .
tep_draw_hidden_field('trx_id', MODULE_PAYMENT_DINEROMAIL_ID) .
tep_draw_hidden_field('image_url', ''). 
tep_draw_hidden_field('DireccionEnvio', '0' ) .
tep_draw_hidden_field('DireccionExito', tep_href_link(FILENAME_CHECKOUT_PROCESS, '', 'SSL')) .
tep_draw_hidden_field('DireccionFracaso', tep_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL'));

return $process_button_string;
}

function before_process() {
return false;
}

function after_process() {
return false;
}

function output_error() {
return false;
}

function check() {
if (!isset($this->_check)) {
$check_query = tep_db_query("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_DINEROMAIL_STATUS'");
$this->_check = tep_db_num_rows($check_query);
}
return $this->_check;
}

function install() {
tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Enable dineromail Module', 'MODULE_PAYMENT_DINEROMAIL_STATUS', 'True', 'Habilitar DineroMail como Medio de Pago?', '6', '3', 'tep_cfg_select_option(array(\'True\', \'False\'), ', now())");
tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('E_Comercio', 'MODULE_PAYMENT_DINEROMAIL_ID', '99999', 'Numero de Cuenta', '6', '4', now())");	
tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Sort order of display.', 'MODULE_PAYMENT_DINEROMAIL_SORT_ORDER', '0', 'Orden', '6', '0', now())");

}

function remove() {
tep_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
}

function keys() {
return array('MODULE_PAYMENT_DINEROMAIL_STATUS', 'MODULE_PAYMENT_DINEROMAIL_ID',  'MODULE_PAYMENT_DINEROMAIL_SORT_ORDER', );
}
}
?>