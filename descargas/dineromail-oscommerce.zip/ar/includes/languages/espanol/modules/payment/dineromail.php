<?php

define('MODULE_PAYMENT_DINEROMAIL_TEXT_TITLE', 'DineroMail - La forma mas sencilla de enviar y recibir dinero via Email <img align="middle" src="https://www.dineromail.com/imagenes/post-login/boton-comprar-01.jpg" border=0');
define('MODULE_PAYMENT_DINEROMAIL_TEXT_DESCRIPTION', 'Texto descriptivo del servicio Dineromail , se puede incluir un banner grafico');

?>