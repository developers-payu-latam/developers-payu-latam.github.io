<?php

/*
  $Id: PayU Latam 22/04/2014 $

  PayU Latam module payment for Oscommerce 2.3.3.4
  http://www.payulatam.com

  @copyright  Copyright (c) 2014 PayU Latam
*/

require('includes/application_top.php');
require(DIR_WS_INCLUDES . 'template_top.php');
require(DIR_WS_LANGUAGES . $language . '/modules/payment/payu_latam.php');

if(isset($_REQUEST['sign'])){
	$signature = $_REQUEST['sign'];
} else {
	$signature = $_REQUEST['firma'];
}

if(isset($_REQUEST['merchant_id'])){
	$merchantId = $_REQUEST['merchant_id'];
} else {
	$merchantId = $_REQUEST['usuario_id'];
}
if(isset($_REQUEST['reference_sale'])){
	$referenceCode = $_REQUEST['reference_sale'];
} else {
	$referenceCode = $_REQUEST['ref_venta'];
}
if(isset($_REQUEST['value'])){
	$value = $_REQUEST['value'];
} else {
	$value = $_REQUEST['valor'];
}
if(isset($_REQUEST['currency'])){
	$currency = $_REQUEST['currency'];
} else {
	$currency = $_REQUEST['moneda'];
}
if(isset($_REQUEST['state_pol'])){
	$transactionState = $_REQUEST['state_pol'];
} else {
	$transactionState = $_REQUEST['estado_pol'];
}

$split = explode('.', $value);
$decimals = $split[1];
if ($decimals % 10 == 0) {
	$value = number_format($value, 1, '.', '');
}

$api_key = MODULE_PAYMENT_PAYU_LATAM_API_KEY;
$signature_local = $api_key . '~' . $merchantId . '~' . $referenceCode . '~' . $value . '~' . $currency . '~' . $transactionState;
$signature_md5 = md5($signature_local);

if(isset($_REQUEST['response_code_pol'])){
	$polResponseCode = $_REQUEST['response_code_pol'];
} else {
	$polResponseCode = $_REQUEST['codigo_respuesta_pol'];
}

if (strtoupper($signature) == strtoupper($signature_md5)) {
	$comments = '';
	$status_name = '';
	if($transactionState == 6 && $polResponseCode == 5){
		$comments = MODULE_PAYMENT_PAYU_LATAM_MESSAGE_FAILED;
		$status_name = MODULE_PAYMENT_PAYU_LATAM_STATUS_FAILED;
	} else if($transactionState == 6 && $polResponseCode == 4){
		$comments = MODULE_PAYMENT_PAYU_LATAM_MESSAGE_REJECTED;
		$status_name = MODULE_PAYMENT_PAYU_LATAM_STATUS_REJECTED;
	} else if($transactionState == 12 && $polResponseCode == 9994){
		$comments = MODULE_PAYMENT_PAYU_LATAM_MESSAGE_PENDING;
		$status_name = MODULE_PAYMENT_PAYU_LATAM_STATUS_PENDING;
	} else if($transactionState == 4 && $polResponseCode == 1){
		$comments = MODULE_PAYMENT_PAYU_LATAM_MESSAGE_APPROVED;
		$status_name = MODULE_PAYMENT_PAYU_LATAM_STATUS_APPROVED;
		$cart->reset(true);
		
		$products_query = "select products_id id, products_quantity qty from " . TABLE_ORDERS_PRODUCTS . " where orders_id = '" . $referenceCode . "'";
		$products = tep_db_query($products_query);
		while ($products_array = tep_db_fetch_array($products)) {
		//************ MANEJO DE LAS EXISTENCIAS - Joao Correia ************//
			if (STOCK_LIMITED == 'true') {
				if (DOWNLOAD_ENABLED == 'true') {
					$stock_query_raw = "SELECT products_quantity, pad.products_attributes_filename 
									  FROM " . TABLE_PRODUCTS . " p
									  LEFT JOIN " . TABLE_PRODUCTS_ATTRIBUTES . " pa
									   ON p.products_id=pa.products_id
									  LEFT JOIN " . TABLE_PRODUCTS_ATTRIBUTES_DOWNLOAD . " pad
									   ON pa.products_attributes_id=pad.products_attributes_id
									  WHERE p.products_id = '" . tep_get_prid($products_array['id']) . "'";
					// Will work with only one option for downloadable products
					// otherwise, we have to build the query dynamically with a loop
					$attributes_query = "select options_id option_id, options_values_id value_id from " . TABLE_PRODUCTS_ATTRIBUTES . " where products_id = '" . $products_array['id'] . "'";
					$attributes = tep_db_query($attributes_query);
					$products_attributes = tep_db_fetch_array($attributes);
					if (is_array($products_attributes) && sizeof($products_attributes) > 0) {
						$stock_query_raw .= " AND pa.options_id = '" . (int)$products_attributes[0]['option_id'] . "' AND pa.options_values_id = '" . (int)$products_attributes[0]['value_id'] . "'";
					}
					$stock_query = tep_db_query($stock_query_raw);
				} else {
					$stock_query = tep_db_query("select products_quantity from " . TABLE_PRODUCTS . " where products_id = '" . tep_get_prid($products_array['id']) . "'");
				}
				if (tep_db_num_rows($stock_query) > 0) {
					$stock_values = tep_db_fetch_array($stock_query);
					// do not decrement quantities if products_attributes_filename exists
					if ((DOWNLOAD_ENABLED != 'true') || (!$stock_values['products_attributes_filename'])) {
						$stock_left = $stock_values['products_quantity'] - $products_array['qty'];
					} else {
						$stock_left = $stock_values['products_quantity'];
					}
					tep_db_query("update " . TABLE_PRODUCTS . " set products_quantity = '" . (int)$stock_left . "' where products_id = '" . tep_get_prid($products_array['id']) . "'");
					if ( ($stock_left < 1) && (STOCK_ALLOW_CHECKOUT == 'false') ) {
						tep_db_query("update " . TABLE_PRODUCTS . " set products_status = '0' where products_id = '" . tep_get_prid($products_array['id']) . "'");
					}
				}
			}
		//************ MANEJO DE LAS EXISTENCIAS - Joao Correia ************//
		}
	} else{
		$comments = MODULE_PAYMENT_PAYU_LATAM_MESSAGE_FAILED;
		$status_name = MODULE_PAYMENT_PAYU_LATAM_STATUS_FAILED;
	}

	$status_query = tep_db_query("select orders_status_id id from " . TABLE_ORDERS_STATUS . " where orders_status_name = '" . $status_name . "' limit 1");
	if (tep_db_num_rows($status_query) > 0) {
		$status = tep_db_fetch_array($status_query);
		$status_id = $status['id'];
		
		tep_db_query("update " . TABLE_ORDERS . " set orders_status = '" . $status_id . "' where orders_id = '" . $referenceCode . "'");
		$customer_notification = (SEND_EMAILS == 'true') ? '1' : '0';
		$sql_data_array = array('orders_id' => $referenceCode, 
							  'orders_status_id' => $status_id, 
							  'date_added' => 'now()', 
							  'customer_notified' => $customer_notification,
							  'comments' => $comments);
		tep_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);
	}
}

require(DIR_WS_INCLUDES . 'template_bottom.php');
require(DIR_WS_INCLUDES . 'application_bottom.php');

?>