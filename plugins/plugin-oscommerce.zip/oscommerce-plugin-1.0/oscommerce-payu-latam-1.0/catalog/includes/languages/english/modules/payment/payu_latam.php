<?php

/*
  $Id: PayU Latam 22/04/2014 $

  PayU Latam module payment for Oscommerce 2.3.3.4
  http://www.payulatam.com

  @copyright  Copyright (c) 2012 PayUn Latam
*/

define('MODULE_PAYMENT_PAYU_LATAM_TEXT_TITLE', 'PayU Latam');
define('MODULE_PAYMENT_PAYU_LATAM_TEXT_PUBLIC_TITLE', 'PayU Latam');
define('MODULE_PAYMENT_PAYU_LATAM_TEXT_DESCRIPTION', '<a href="http://payulatam.com/" target="_blank" style="text-decoration: underline; font-weight: bold;">PayU Latam</a>');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE', '�Thank you for your purchase!');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE_FAILED', 'Failed Transaction');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE_REJECTED', 'Rejected Transaction');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE_PENDING', 'Pending Transaction, Please check if the debit was made in the Bank');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE_APPROVED', 'Transaction Approved');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_DATA', 'Purchase Data');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_TX_STATE', 'Transaction State');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_TX_ID', 'Transaction ID');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_REFERENCE', 'Purchase Reference');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_TX_REFERENCE', 'Transaction Reference');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_BANK', 'Bank');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_TOTAL_VALUE', 'Total Value');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_CURRENCY', 'Currency');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_DESC', 'Description');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_ENTITY', 'Entity');
define('MODULE_PAYMENT_PAYU_LATAM_ERROR_SIGNATURE', 'The request is incorrect! There is an error in the digital signature.');
define('MODULE_PAYMENT_PAYU_LATAM_STATUS_APPROVED', 'Approved');
define('MODULE_PAYMENT_PAYU_LATAM_STATUS_REJECTED', 'Rejected');
define('MODULE_PAYMENT_PAYU_LATAM_STATUS_FAILED', 'Failed');
define('MODULE_PAYMENT_PAYU_LATAM_STATUS_PENDING', 'Pending');

?>