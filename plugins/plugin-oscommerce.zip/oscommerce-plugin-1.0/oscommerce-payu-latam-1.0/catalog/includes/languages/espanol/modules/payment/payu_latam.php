<?php

/*
  $Id: PayU Latam 22/04/2014 $

  PayU Latam module payment for Oscommerce 2.3.3.4
  http://www.payulatam.com

  @copyright  Copyright (c) 2012 PayUn Latam
*/

define('MODULE_PAYMENT_PAYU_LATAM_TEXT_TITLE', 'PayU Latam');
define('MODULE_PAYMENT_PAYU_LATAM_TEXT_PUBLIC_TITLE', 'PayU Latam');
define('MODULE_PAYMENT_PAYU_LATAM_TEXT_DESCRIPTION', '<a href="http://payulatam.com/" target="_blank" style="text-decoration: underline; font-weight: bold;">PayU Latam</a>');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE', '�Gracias por su compra!');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE_FAILED', 'Transacci�n fallida');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE_REJECTED', 'Transacci�n rechazada');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE_PENDING', 'Pendiente, Por favor revisar si el d�bito fue realizado en el Banco');
define('MODULE_PAYMENT_PAYU_LATAM_MESSAGE_APPROVED', 'Transacci�n aprobada');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_DATA', 'DATOS DE LA COMPRA');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_TX_STATE', 'Estado de la transacci�n');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_TX_ID', 'ID de la transacci�n');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_REFERENCE', 'Referencia de la venta');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_TX_REFERENCE', 'Referencia de la transacci�n');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_BANK', 'Banco');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_TOTAL_VALUE', 'Valor total');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_CURRENCY', 'Moneda');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_DESC', 'Descripci�n');
define('MODULE_PAYMENT_PAYU_LATAM_LABEL_ENTITY', 'Entidad');
define('MODULE_PAYMENT_PAYU_LATAM_ERROR_SIGNATURE', 'La petici�n es incorrecta! Hay un error en la firma digital.');
define('MODULE_PAYMENT_PAYU_LATAM_STATUS_APPROVED', 'Aprobada');
define('MODULE_PAYMENT_PAYU_LATAM_STATUS_REJECTED', 'Rechazada');
define('MODULE_PAYMENT_PAYU_LATAM_STATUS_FAILED', 'Fallida');
define('MODULE_PAYMENT_PAYU_LATAM_STATUS_PENDING', 'Pendiente');

?>