<?php

/*
  $Id: PayU Latam 22/04/2014 $

  PayU Latam module payment for Oscommerce 2.3.3.4
  http://www.payulatam.com

  @copyright  Copyright (c) 2014 PayU Latam
*/

require('includes/application_top.php');
require(DIR_WS_INCLUDES . 'template_top.php');
require(DIR_WS_LANGUAGES . $language . '/modules/payment/payu_latam.php');

if(isset($_REQUEST['signature'])){
	$signature = $_REQUEST['signature'];
} else {
	$signature = $_REQUEST['firma'];
}

if(isset($_REQUEST['merchantId'])){
	$merchantId = $_REQUEST['merchantId'];
} else {
	$merchantId = $_REQUEST['usuario_id'];
}
if(isset($_REQUEST['referenceCode'])){
	$referenceCode = $_REQUEST['referenceCode'];
} else {
	$referenceCode = $_REQUEST['ref_venta'];
}
if(isset($_REQUEST['TX_VALUE'])){
	$value = $_REQUEST['TX_VALUE'];
} else {
	$value = $_REQUEST['valor'];
}
if(isset($_REQUEST['currency'])){
	$currency = $_REQUEST['currency'];
} else {
	$currency = $_REQUEST['moneda'];
}
if(isset($_REQUEST['transactionState'])){
	$transactionState = $_REQUEST['transactionState'];
} else {
	$transactionState = $_REQUEST['estado'];
}

$value = number_format($value, 1, '.', '');
$api_key = MODULE_PAYMENT_PAYU_LATAM_API_KEY;
$merchantId = MODULE_PAYMENT_PAYU_LATAM_MERCHANT_ID;
$signature_local = $api_key . '~' . $merchantId . '~' . $referenceCode . '~' . $value . '~' . $currency . '~' . $transactionState;
$signature_md5 = md5($signature_local);

if(isset($_REQUEST['polResponseCode'])){
	$polResponseCode = $_REQUEST['polResponseCode'];
} else {
	$polResponseCode = $_REQUEST['codigo_respuesta_pol'];
}

$message = '';
if($transactionState == 6 && $polResponseCode == 5){
	$estadoTx = MODULE_PAYMENT_PAYU_LATAM_MESSAGE_FAILED;
} else if($transactionState == 6 && $polResponseCode == 4){
	$estadoTx = MODULE_PAYMENT_PAYU_LATAM_MESSAGE_REJECTED;
} else if($transactionState == 12 && $polResponseCode == 9994){
	$estadoTx = MODULE_PAYMENT_PAYU_LATAM_MESSAGE_PENDING;
} else if($transactionState == 4 && $polResponseCode == 1){
	$estadoTx = MODULE_PAYMENT_PAYU_LATAM_MESSAGE_APPROVED;
	$message = MODULE_PAYMENT_PAYU_LATAM_MESSAGE;
} else{
	if(isset($_REQUEST['message'])){
		$estadoTx=$_REQUEST['message'];
	} else {
		$estadoTx=$_REQUEST['mensaje'];
	}
}

if(isset($_REQUEST['transactionId'])){
	$transactionId = $_REQUEST['transactionId'];
} else {
	$transactionId = $_REQUEST['transaccion_id'];
}
if(isset($_REQUEST['reference_pol'])){
	$reference_pol = $_REQUEST['reference_pol'];
} else {
	$reference_pol = $_REQUEST['ref_pol'];
}
if(isset($_REQUEST['pseBank'])){
	$pseBank = $_REQUEST['pseBank'];
} else {
	$pseBank = $_REQUEST['banco_pse'];
}
$cus = $_REQUEST['cus'];
if(isset($_REQUEST['description'])){
	$description = $_REQUEST['description'];
} else {
	$description = $_REQUEST['descripcion'];
}
if(isset($_REQUEST['lapPaymentMethod'])){
	$lapPaymentMethod = $_REQUEST['lapPaymentMethod'];
} else {
	$lapPaymentMethod = $_REQUEST['medio_pago_lap'];
}

if (strtoupper($signature) == strtoupper($signature_md5)) {
?>
	<center>
		<table style="width: 70%; margin-top: 100px; border-spacing: 5px !important;">
			<tr align="center">
				<th colspan="2"><?php echo MODULE_PAYMENT_PAYU_LATAM_LABEL_DATA; ?></th>
			</tr>
			<tr>
				<td><?php echo MODULE_PAYMENT_PAYU_LATAM_LABEL_TX_STATE; ?></td>
				<td><?php echo $estadoTx; ?></td>
			</tr>
			<tr>
				<td><?php echo MODULE_PAYMENT_PAYU_LATAM_LABEL_TX_ID; ?></td>
				<td><?php echo $transactionId; ?></td>
			</tr>		
			<tr>
				<td><?php echo MODULE_PAYMENT_PAYU_LATAM_LABEL_REFERENCE; ?></td>
				<td><?php echo $reference_pol; ?></td>
			</tr>		
			<tr>
				<td><?php echo MODULE_PAYMENT_PAYU_LATAM_LABEL_TX_REFERENCE; ?></td>
				<td><?php echo $referenceCode; ?></td>
			</tr>	
			<?php
				if($pseBank!=null){
			?>
				<tr>
					<td>CUS</td>
					<td><?php echo $cus; ?> </td>
				</tr>
				<tr>
					<td><?php echo MODULE_PAYMENT_PAYU_LATAM_LABEL_BANK; ?></td>
					<td><?php echo $pseBank; ?> </td>
				</tr>
			<?php
				}
			?>
			<tr>
				<td><?php echo MODULE_PAYMENT_PAYU_LATAM_LABEL_TOTAL_VALUE; ?></td>
				<td>$<?php echo $value; ?> </td>
			</tr>
			<tr>
				<td><?php echo MODULE_PAYMENT_PAYU_LATAM_LABEL_CURRENCY; ?></td>
				<td><?php echo $currency; ?></td>
			</tr>
			<tr>
				<td><?php echo MODULE_PAYMENT_PAYU_LATAM_LABEL_DESC; ?></td>
				<td><?php echo $description; ?></td>
			</tr>
			<tr>
				<td><?php echo MODULE_PAYMENT_PAYU_LATAM_LABEL_ENTITY; ?></td>
				<td><?php echo $lapPaymentMethod; ?></td>
			</tr>
		</table>
		<p/>
		<h1><?php echo $message; ?></h1>
	</center>
<?php
} else {
	echo '<h1><center>' . MODULE_PAYMENT_PAYU_LATAM_ERROR_SIGNATURE . '</center></h1>';
}

require(DIR_WS_INCLUDES . 'template_bottom.php');
require(DIR_WS_INCLUDES . 'application_bottom.php');

?>