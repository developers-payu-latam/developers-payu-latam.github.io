-- Remove all required data

DELETE FROM `#__virtuemart_permgroups`;
DELETE FROM `#__virtuemart_countries`;
DELETE FROM `#__virtuemart_currencies`;
DELETE FROM `#__virtuemart_paymentmethods`;
DELETE FROM `#__virtuemart_shipmentmethods`;
DELETE FROM `#__virtuemart_shoppergroups`;
DELETE FROM `#__virtuemart_vmuser_shoppergroups`;
DELETE FROM `#__virtuemart_states`;