Drupal commerce_payulatam module:
------------------------
Maintainers:
  Jeisson Perez Molano (http://drupal.org/user/143187)
Requires - Drupal 7
License - GPL (see LICENSE)


Overview:
--------
Drupal Commerce payment module for http://www.payulatam.com

Configuration:
-------------
Go to "Store" -> "Configuration" -> "Payment methods" ->  to find
all the configuration options.

Reports:
---------------------
admin/commerce_payulatam/report

